/*******************************************************************************
* Copyright (c) 2018-2026 Cadence Design Systems, Inc.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to use this Software with Cadence processor cores only and
* not with any other processors and platforms, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

******************************************************************************/
#ifndef __XA_NNLIB_QUANT_MACROS_HIFI5_H__
#define __XA_NNLIB_QUANT_MACROS_HIFI5_H__
#if TFLITE_SINGLE_ROUNDING

#if XCHAL_HAVE_HIFI5S


#define MPY_BY_QUANT_MULT_X2_OUT32_HIFI5S(out, inp, multiplier, left_shift, right_shift) \
{ \
  ae_int64 out64_0, out64_1; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp, SW_MOVDA32(multiplier)); \
  out = AE_ROUNDAV32X2F64SASYM(out64_0, out64_1, left_shift); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT32_HIFI5S(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, SW_MOVDA32(multiplier)); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, SW_MOVDA32(multiplier)); \
  out1 = AE_ROUNDAV32X2F64SASYM(out64_0, out64_1, left_shift); \
  out2 = AE_ROUNDAV32X2F64SASYM(out64_2, out64_3, left_shift); \
}

#endif // XCHAL_HAVE_HIFI5S

#define MPY_BY_QUANT_MULT_X2_OUT32(out, inp, multiplier, left_shift, right_shift) \
{ \
  ae_int64 out64_0, out64_1; \
  ae_int64 INT64_ONE = AE_MOVINT64_FROMINT32X2(AE_MOVDA32X2(0,1)); \
  ae_int64 round_val = AE_MOVINT64_FROMF64(AE_SLAA64S(AE_MOVF64_FROMINT64(INT64_ONE), 30 - left_shift)); \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp, SW_MOVDA32(multiplier)); \
  out64_0 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_0), AE_MOVF64_FROMINT64(round_val))); \
  out64_1 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_1), AE_MOVF64_FROMINT64(round_val))); \
  out = AE_TRUNCA32X2F64S(out64_0, out64_1, 1 + left_shift); \
}

#define MPY_BY_QUANT_MULT_SLS_X2_OUT32(out, inp, multiplier, left_shift, right_shift) \
  MPY_BY_QUANT_MULT_X2_OUT32(out, inp, multiplier, left_shift, right_shift)

#define MPY_BY_QUANT_MULT_X2X2_INP16_OUT32(out1, out2, inp, multiplier, left_shift, right_shift)\
{\
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int64 INT64_ONE = AE_MOVINT64_FROMINT32X2(AE_MOVDA32X2(0,1)); \
  ae_int64 round_val = AE_MOVINT64_FROMF64(AE_SLAA64S(AE_MOVF64_FROMINT64(INT64_ONE), 30 - left_shift + 1)); \
  ae_f64 out64_0_t, out64_1_t, out64_2_t, out64_3_t; \
  AE_MULFP32X16_H(out64_0_t, out64_1_t, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF16X4_FROMINT16X4(inp)); \
  AE_MULFP32X16_L(out64_2_t, out64_3_t, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF16X4_FROMINT16X4(inp)); \
  out64_0 = AE_MOVINT64_FROMF64(AE_ADD64S(out64_0_t, AE_MOVF64_FROMINT64(round_val))); \
  out64_1 = AE_MOVINT64_FROMF64(AE_ADD64S(out64_1_t, AE_MOVF64_FROMINT64(round_val))); \
  out64_2 = AE_MOVINT64_FROMF64(AE_ADD64S(out64_2_t, AE_MOVF64_FROMINT64(round_val))); \
  out64_3 = AE_MOVINT64_FROMF64(AE_ADD64S(out64_3_t, AE_MOVF64_FROMINT64(round_val))); \
  out1 = AE_TRUNCA32X2F64S(out64_0, out64_1, left_shift); \
  out2 = AE_TRUNCA32X2F64S(out64_2, out64_3, left_shift); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int64 INT64_ONE = AE_MOVINT64_FROMINT32X2(AE_MOVDA32X2(0,1)); \
  ae_int64 round_val = AE_MOVINT64_FROMF64(AE_SLAA64S(AE_MOVF64_FROMINT64(INT64_ONE), 30 - left_shift)); \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, SW_MOVDA32(multiplier)); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, SW_MOVDA32(multiplier)); \
  out64_0 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_0), AE_MOVF64_FROMINT64(round_val))); \
  out64_1 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_1), AE_MOVF64_FROMINT64(round_val))); \
  out64_2 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_2), AE_MOVF64_FROMINT64(round_val))); \
  out64_3 = AE_MOVINT64_FROMF64(AE_ADD64S(AE_MOVF64_FROMINT64(out64_3), AE_MOVF64_FROMINT64(round_val))); \
  out1 = AE_TRUNCA32X2F64S(out64_0, out64_1, 1 + left_shift); \
  out2 = AE_TRUNCA32X2F64S(out64_2, out64_3, 1 + left_shift); \
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
  MPY_BY_QUANT_MULT_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift)

#define MPY_BY_QUANT_MULT_X2_OUT16(out, inp, multiplier, left_shift, right_shift) \
{ \
  ae_int64 out64_0, out64_1; \
  ae_int32x2 out32_0; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp, SW_MOVDA32(multiplier)); \
  out32_0 = AE_TRUNCA32X2F64S(out64_0, out64_1, left_shift + 17); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_0))); \
}


#define MPY_BY_QUANT_MULT_X4_INP16_OUT16_ZB(out, inp, multiplier, l_shift, r_shift, out_off) \
{\
  ae_f64 out64_0, out64_1, out64_2, out64_3; \
  ae_int32x2 out32_0, out32_1; \
  AE_MULFP32X16_H(out64_0, out64_1, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF16X4_FROMINT16X4(inp)); \
  AE_MULFP32X16_L(out64_2, out64_3, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF16X4_FROMINT16X4(inp)); \
  out32_0 = AE_TRUNCA32X2F64S(AE_MOVINT64_FROMF64(out64_0), AE_MOVINT64_FROMF64(out64_1), l_shift + 17 - 1); \
  out32_1 = AE_TRUNCA32X2F64S(AE_MOVINT64_FROMF64(out64_2), AE_MOVINT64_FROMF64(out64_3), l_shift + 17 - 1); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT16_MULTPLIERINX2(out, inp1, inp2, multiplier, l_shift, r_shift) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int32x2 out32_0, out32_1; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, multiplier); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, multiplier); \
  out32_0 = AE_TRUNCA32X2F64S(out64_0, out64_1, l_shift + 17); \
  out32_1 = AE_TRUNCA32X2F64S(out64_2, out64_3, l_shift + 17); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT16(out, inp1, inp2, multiplier, l_shift, r_shift) \
{\
 MPY_BY_QUANT_MULT_X2X2_OUT16_MULTPLIERINX2(out, inp1, inp2, SW_MOVDA32(multiplier), l_shift, r_shift)\
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT16 MPY_BY_QUANT_MULT_X2X2_OUT16

#define MPY_BY_QUANT_MULT_X2X2_OUT16_ZB(out, inp1, inp2, multiplier, l_shift, r_shift, out_off) \
{ \
  MPY_BY_QUANT_MULT_X2X2_OUT16(out, inp1, inp2, multiplier, l_shift, r_shift) \
  out = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT16_ZB MPY_BY_QUANT_MULT_X2X2_OUT16_ZB

#ifdef AE_TRUNCAV32X2F64S
#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB_AV(out, inp1, inp2, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int32x2 out32_0, out32_1; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, mult_01); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, mult_23); \
  out32_0 = AE_TRUNCAV32X2F64S(out64_0, out64_1, AE_MOVAD32_H(ls_01)); \
  out32_1 = AE_TRUNCAV32X2F64S(out64_2, out64_3, AE_MOVAD32_L(ls_01)); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}
#else
#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB_AV MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB
#endif

#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int32x2 out32_0, out32_1, out32_2, out32_3; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, mult_01); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, mult_23); \
  out32_0 = AE_TRUNCA32F64S(out64_0, AE_MOVAD32_H(ls_01) + 17); \
  out32_1 = AE_TRUNCA32F64S(out64_1, AE_MOVAD32_L(ls_01) + 17); \
  out32_2 = AE_TRUNCA32F64S(out64_2, AE_MOVAD32_H(ls_23) + 17); \
  out32_3 = AE_TRUNCA32F64S(out64_3, AE_MOVAD32_L(ls_23) + 17); \
  out32_0 = AE_SEL32_LL(out32_0, out32_1); \
  out32_1 = AE_SEL32_LL(out32_2, out32_3); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_X2_OUT16_ZB(out, out_a, inp1, inp2, inp1_a, inp2_a, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
{ \
  ae_int64 out64_0, out64_1, out64_2, out64_3; \
  ae_int64 out64_0_a, out64_1_a, out64_2_a, out64_3_a; \
  ae_int32x2 out32_0, out32_1, out32_2, out32_3; \
  AE_MUL32X2S_HH_LL(out64_0, out64_1, inp1, mult_01); \
  AE_MUL32X2S_HH_LL(out64_2, out64_3, inp2, mult_23); \
  AE_MUL32X2S_HH_LL(out64_0_a, out64_1_a, inp1_a, mult_01); \
  AE_MUL32X2S_HH_LL(out64_2_a, out64_3_a, inp2_a, mult_23); \
  out32_0 = AE_TRUNCA32X2F64S(out64_0, out64_0_a, AE_MOVAD32_H(ls_01) + 17); \
  out32_1 = AE_TRUNCA32X2F64S(out64_1, out64_1_a, AE_MOVAD32_L(ls_01) + 17); \
  out32_2 = AE_TRUNCA32X2F64S(out64_2, out64_2_a, AE_MOVAD32_H(ls_23) + 17); \
  out32_3 = AE_TRUNCA32X2F64S(out64_3, out64_3_a, AE_MOVAD32_L(ls_23) + 17); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(AE_SEL32_HH(out32_0, out32_1)), AE_MOVF32X2_FROMINT32X2(AE_SEL32_HH(out32_2, out32_3)))); \
  out_a = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(AE_SEL32_LL(out32_0, out32_1)), AE_MOVF32X2_FROMINT32X2(AE_SEL32_LL(out32_2, out32_3)))); \
  out = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
  out_a = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out_a))); \
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT32_ALT(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
  MPY_BY_QUANT_MULT_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) 

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB_AV(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB_AV(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off)

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off)

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_X2_OUT16_ZB(out, out_a, inp1, inp2, inp1_a, inp2_a, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_X2X2_X2_OUT16_ZB(out, out_a, inp1, inp2, inp1_a, inp2_a, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off)

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32(prod, val, multiplier, lsh) \
{ \
  ae_int32x2 mult_ls0, mult_ls1; \
  xtbool2 b0 = AE_EQ32(SW_MOVDA32(lsh), AE_ZERO32()); \
  mult_ls0 = mult_ls1 = SW_MOVDA32(multiplier); \
  AE_MOVF32X2(mult_ls0, AE_ZERO32(), b0); \
  AE_MOVT32X2(mult_ls1, AE_ZERO32(), b0); \
  prod = (AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(val), AE_MOVF32X2_FROMINT32X2(mult_ls0))); \
  AE_MULAFP32X2TS(prod, AE_MOVF32X2_FROMINT32X2(val), AE_MOVF32X2_FROMINT32X2(mult_ls1)); \
  prod = AE_SRAA32RS(prod, -lsh); \
}

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT32(prod0, prod1, val0, val1, multiplier, lsh) \
{ \
  ae_int32x2 mult_ls0, mult_ls1; \
  xtbool2 b0 = AE_EQ32(SW_MOVDA32(lsh), AE_ZERO32()); \
  mult_ls0 = mult_ls1 = SW_MOVDA32(multiplier); \
  AE_MOVF32X2(mult_ls0, AE_ZERO32(), b0); \
  AE_MOVT32X2(mult_ls1, AE_ZERO32(), b0); \
  AE_MULF2P32X4RAS(prod0, prod1, val0, val1, AE_MOVF32X2_FROMINT32X2(mult_ls0), AE_MOVF32X2_FROMINT32X2(mult_ls0)); \
  AE_MULAFP32X2TS(prod0, val0, AE_MOVF32X2_FROMINT32X2(mult_ls1)); \
  AE_MULAFP32X2TS(prod1, val1, AE_MOVF32X2_FROMINT32X2(mult_ls1)); \
  prod0 = AE_SRAA32RS(prod0, -lsh); \
  prod1 = AE_SRAA32RS(prod1, -lsh); \
}

#define MPY_BY_QUANT_MACC_ST_ONE_EXP_X2X2_OUT32(acc0, acc1, val0, val1, multiplier, lsh) \
{ \
  ae_int32x2 mult_ls0, mult_ls1; \
  ae_int32x2 out0, out1; \
  xtbool2 b0 = AE_EQ32(SW_MOVDA32(lsh), AE_ZERO32()); \
  mult_ls0 = mult_ls1 = SW_MOVDA32(multiplier); \
  AE_MOVF32X2(mult_ls0, AE_ZERO32(), b0); \
  AE_MOVT32X2(mult_ls1, AE_ZERO32(), b0); \
  out0 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2TS(AE_MOVF32X2_FROMINT32X2(val0), AE_MOVF32X2_FROMINT32X2(mult_ls1))); \
  out1 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2TS(AE_MOVF32X2_FROMINT32X2(val1), AE_MOVF32X2_FROMINT32X2(mult_ls1))); \
  ae_f32x2 outf0 = AE_MOVF32X2_FROMINT32X2(out0); \
  ae_f32x2 outf1 = AE_MOVF32X2_FROMINT32X2(out1); \
  AE_MULSF2P32X4RAS(outf0, outf1, AE_MOVF32X2_FROMINT32X2(val0), AE_MOVF32X2_FROMINT32X2(val1), AE_MOVF32X2_FROMINT32X2(mult_ls0), AE_MOVF32X2_FROMINT32X2(mult_ls0)); \
  AE_MULAF2P32X4RAS(acc0, acc1, outf0, outf1, AE_MOVF32X2_FROMINT32X2(AE_SRLA32(SW_MOVDA32(0x80000000), -lsh)), AE_MOVF32X2_FROMINT32X2(AE_SRLA32(SW_MOVDA32(0x80000000), -lsh))); \
}

#define MPY_BY_QUANT_MSUB_ST_ONE_EXP_X2X2_OUT32(acc0, acc1, val0, val1, multiplier, lsh) \
{ \
  ae_int32x2 mult_ls0, mult_ls1; \
  ae_int32x2 out0, out1; \
  xtbool2 b0 = AE_EQ32(SW_MOVDA32(lsh), AE_ZERO32()); \
  mult_ls0 = mult_ls1 = SW_MOVDA32(multiplier); \
  AE_MOVF32X2(mult_ls0, AE_ZERO32(), b0); \
  AE_MOVT32X2(mult_ls1, AE_ZERO32(), b0); \
  out0 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2TS(AE_MOVF32X2_FROMINT32X2(val0), AE_MOVF32X2_FROMINT32X2(mult_ls1))); \
  out1 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2TS(AE_MOVF32X2_FROMINT32X2(val1), AE_MOVF32X2_FROMINT32X2(mult_ls1))); \
  ae_f32x2 out0_t = AE_MOVF32X2_FROMINT32X2(out0); \
  ae_f32x2 out1_t = AE_MOVF32X2_FROMINT32X2(out1); \
  AE_MULSF2P32X4RAS(out0_t, out1_t, AE_MOVF32X2_FROMINT32X2(val0), AE_MOVF32X2_FROMINT32X2(val1), AE_MOVF32X2_FROMINT32X2(mult_ls0), AE_MOVF32X2_FROMINT32X2(mult_ls0)); \
  AE_MULSF2P32X4RAS(acc0, acc1, out0_t, out1_t, AE_MOVF32X2_FROMINT32X2(AE_SRLA32(SW_MOVDA32(0x80000000), -lsh)), AE_MOVF32X2_FROMINT32X2(AE_SRLA32(SW_MOVDA32(0x80000000), -lsh))); \
}

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT32_ZB(prod0, prod1, val0, val1, multiplier, lsh, out_off) \
    prod0 = prod1 = AE_MOVF32X2_FROMINT32(AE_MOVDA32(out_off)); \
    MPY_BY_QUANT_MACC_ST_ONE_EXP_X2X2_OUT32(prod0, prod1, val0, val1, multiplier, lsh)

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32_X2(prod1, prod2, val1, val2, multiplier1, multiplier2, lsh1, lsh2) \
    MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32(prod1, val1, multiplier1, lsh1) \
    MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32(prod2, val2, multiplier2, lsh2)

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT16_ZB(out0, val0, val1, multiplier, lsh, out_off) \
{ \
  MPY_BY_QUANT_MULT_X2X2_OUT16(out0, AE_MOVINT32X2_FROMF32X2(val0), AE_MOVINT32X2_FROMF32X2(val1), multiplier, lsh, lsh) \
  out0 = AE_MOVINT16X4_FROMF16X4(AE_ADD16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out0))); \
}
    //MPY_BY_QUANT_MULT_X2X2_OUT16_ZB(out0, val0, val1, multiplier, lsh, lsh, out_off)

#define MPY_BY_QUANT_MULT_GT_ONE_X2_OUT32(y, x, multiplier, lsh) \
    MPY_BY_QUANT_MULT_X2_OUT32(y, x, multiplier, lsh, lsh)

#define MPY_BY_QUANT_MULT_GT_ONE_X2X2_OUT32(y, z, l, m, multiplier, lsh) \
    MPY_BY_QUANT_MULT_X2X2_OUT32(y, z, l, m, multiplier, lsh, lsh)

#else /* #if TFLITE_SINGLE_ROUNDING */

#define MPY_BY_QUANT_MULT_X2_OUT32(out, inp, multiplier, left_shift, right_shift) \
  out = AE_SLAA32(inp, left_shift); \
  out = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(out), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)))); \
  out = AE_SRAA32SYMS(out, right_shift);

#define MPY_BY_QUANT_MULT_SLS_X2_OUT32(out, inp, multiplier, left_shift, right_shift) \
  out = SW_SLAA32S_INT32X2_INT32X2(inp, left_shift); \
  out = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(out), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)))); \
  out = AE_SRAA32SYMS(out, right_shift);

#define MPY_BY_QUANT_MULT_X2X2_INP16_OUT32(out1, out2, inp, multiplier, left_shift, right_shift)\
{\
  ae_f32x2 out1_t, out2_t; \
  AE_CVTA32X4F16S(out1_t, out2_t, inp,left_shift); \
  AE_MULF2P32X4RAS(out1_t, out2_t, out1_t, out2_t, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
  out1 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(out1_t), right_shift); \
  out2 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(out2_t), right_shift); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
{ \
  ae_int32x2 d_ls = SW_MOVDA32(1<<left_shift); \
  AE_MUL2P32X4S(out1, out2, inp1, inp2, d_ls, d_ls); \
  ae_f32x2 fout1 = AE_MOVF32X2_FROMINT32X2(out1); \
  ae_f32x2 fout2 = AE_MOVF32X2_FROMINT32X2(out2); \
  AE_MULF2P32X4RAS(fout1, fout2, fout1, fout2, AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier))); \
  out1 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(fout1), right_shift); \
  out2 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(fout2), right_shift); \
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT32(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
{ \
  ae_int32x2 d_ls = SW_MOVDA32(1<<left_shift); \
  AE_MUL2P32X4S(out1, out2, inp1, inp2, d_ls, d_ls); \
  ae_f32x2 out1f = AE_MOVF32X2_FROMINT32X2(out1); \
  ae_f32x2 out2f = AE_MOVF32X2_FROMINT32X2(out2); \
  AE_MULF2P32X4RAS(out1f, out2f, out1f, out2f, AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier))); \
  out1 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(out1f), right_shift); \
  out2 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(out2f), right_shift); \
}

#define MPY_BY_QUANT_MULT_X2_OUT16(out, inp, multiplier, left_shift, right_shift) \
{ \
  ae_int32x2 out32_0; \
  out32_0 = AE_MOVINT32X2_FROMF32X2(AE_SLAA32S(AE_MOVF32X2_FROMINT32X2(inp), left_shift)); \
  out32_0 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)))); \
  out32_0 = AE_SRAA32SYMS(out32_0, right_shift); \
  out = AE_SAT16X4(out32_0, out32_0); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT16_MULTPLIERINX2(out, inp1, inp2, multiplier, l_shift, r_shift) \
{\
  ae_f32x2 temp1, temp2; \
  AE_MUL2P32X4S(inp1, inp2, inp1, inp2, SW_MOVDA32(1 << l_shift), SW_MOVDA32(1 << l_shift)); \
  AE_MULF2P32X4RAS(temp1, temp2, AE_MOVF32X2_FROMINT32X2(inp1), AE_MOVF32X2_FROMINT32X2(inp2), AE_MOVF32X2_FROMINT32X2(AE_NEG32(multiplier)), AE_MOVF32X2_FROMINT32X2(AE_NEG32(multiplier))); \
  AE_MULF2P32X4RS(temp1, temp2, temp1, temp2, AE_MOVF32X2_FROMINT32X2(AE_SRAA32(SW_MOVDA32(0x80000000), r_shift)), AE_MOVF32X2_FROMINT32X2(AE_SRAA32(SW_MOVDA32(0x80000000), r_shift))); \
  out = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(temp1), AE_MOVINT32X2_FROMF32X2(temp2)); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT16(out, inp1, inp2, multiplier, l_shift, r_shift) \
{\
 MPY_BY_QUANT_MULT_X2X2_OUT16_MULTPLIERINX2(out, inp1, inp2, SW_MOVDA32(multiplier), l_shift, r_shift)\
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT16(out, inp1, inp2, multiplier, l_shift, r_shift) \
{ \
  ae_f32x2 inp1_f32x2, inp2_f32x2; \
  AE_MUL2P32X4S(inp1, inp2, inp1, inp2, SW_SLAA32S_INT32X2_INT32X2(AE_MOVI(1), l_shift), SW_SLAA32S_INT32X2_INT32X2(AE_MOVI(1), l_shift)); \
  AE_MULF2P32X4RAS(inp1_f32x2, inp2_f32x2, AE_MOVF32X2_FROMINT32X2(inp1), AE_MOVF32X2_FROMINT32X2(inp2), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
  inp1 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(inp1_f32x2), r_shift); \
  inp2 = AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(inp2_f32x2), r_shift); \
  out = AE_SAT16X4(inp1, inp2); \
}

#define MPY_BY_QUANT_MULT_X4_INP16_OUT16_ZB(out, inp, multiplier, l_shift, r_shift, out_off) \
{\
  ae_f32x2 out1, out2; \
  AE_CVTA32X4F16S(out1, out2, inp,l_shift); \
  AE_MULF2P32X4RAS(out1, out2, out1, out2, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
  AE_MULF2P32X4RS(out1, out2, out1, out2, AE_SRAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), r_shift), AE_SRAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), r_shift));      \
  out = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(out1), AE_MOVINT32X2_FROMF32X2(out2)); \
  out = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_X2X2_OUT16_ZB(out, inp1, inp2, multiplier, l_shift, r_shift, out_off) \
{ \
  ae_f32x2 temp_o1, temp_o2; \
  AE_MUL2P32X4S(inp1, inp2, inp1, inp2, SW_SLAA32S_INT32X2_INT32X2(AE_MOVI(1), l_shift), SW_SLAA32S_INT32X2_INT32X2(AE_MOVI(1), l_shift)); \
  AE_MULF2P32X4RAS(temp_o1, temp_o2, AE_MOVF32X2_FROMINT32X2(inp1), AE_MOVF32X2_FROMINT32X2(inp2), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier))); \
  AE_MULF2P32X4RS(temp_o1, temp_o2, temp_o1, temp_o2, SW_SRAA32S_INT32X2_F32X2(SW_MOVDA32(0x80000000), r_shift), SW_SRAA32S_INT32X2_F32X2(SW_MOVDA32(0x80000000), r_shift));      \
  out = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(temp_o1), AE_MOVINT32X2_FROMF32X2(temp_o2)); \
  out = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}
 
#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT16_ZB(out, inp1, inp2, multiplier, l_shift, r_shift, out_off) \
{ \
  temp1 = AE_MOVF32X2_FROMINT32X2(inp1); \
  temp2 = AE_MOVF32X2_FROMINT32X2(inp2); \
  temp1 = AE_SLAA32S(temp1, l_shift); \
  temp2 = AE_SLAA32S(temp2, l_shift); \
  temp_multiplier = AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)); \
  AE_MULF2P32X4RAS(temp1, temp2, temp1, temp2, temp_multiplier, temp_multiplier); \
  sraa32_temp = AE_SRAA32S(AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(0x80000000)), r_shift); \
  AE_MULF2P32X4RS(temp1, temp2, temp1, temp2, sraa32_temp, sraa32_temp);      \
  inp1 = AE_MOVINT32X2_FROMF32X2(temp1); \
  inp2 = AE_MOVINT32X2_FROMF32X2(temp2); \
  out = AE_SAT16X4(inp1, inp2); \
  out = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
 }

#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB_AV MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB

#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
{\
  AE_MUL2P32X4S(inp1, inp2, inp1, inp2, AE_SRAV32RS(AE_MOVI(1), AE_NEG32(ls_01)), AE_SRAV32RS(AE_MOVI(1), AE_NEG32(ls_23))); \
  ae_f32x2 i1 = AE_MOVF32X2_FROMINT32X2(inp1); \
  ae_f32x2 i2 = AE_MOVF32X2_FROMINT32X2(inp2); \
  ae_f32x2 temp_srav = AE_MOVF32X2_FROMINT32X2(AE_SRAV32RS(SW_MOVDA32(0x80000000), rs_01)); \
  ae_f32x2 temp1_srav = AE_MOVF32X2_FROMINT32X2(AE_SRAV32RS(SW_MOVDA32(0x80000000), rs_23)); \
  AE_MULF2P32X4RAS(i1, i2, i1, i2, AE_MOVF32X2_FROMINT32X2(mult_01), AE_MOVF32X2_FROMINT32X2(mult_23)); \
  AE_MULF2P32X4RS(i1, i2, i1, i2,temp_srav ,temp1_srav ); \
  out = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(i1), AE_MOVINT32X2_FROMF32X2(i2)); \
  out = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_PER_CHAN_X2X2_X2_OUT16_ZB(out, out_a, inp1, inp2, inp1_a, inp2_a, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_X2X2_OUT16_ZB(out_a, inp1_a, inp2_a, mult_01, mult_23, ls_01, ls_23, rs_01, rs_23, out_off)

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB_AV MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off) \
{\
  AE_MUL2P32X4S(inp1, inp2, inp1, inp2, ls_mult_01, ls_mult_23); \
  ae_f32x2 inp1_t = AE_MOVF32X2_FROMINT32X2(inp1); \
  ae_f32x2 inp2_t = AE_MOVF32X2_FROMINT32X2(inp2); \
  AE_MULF2P32X4RAS(inp1_t, inp2_t, inp1_t, inp2_t, AE_MOVF32X2_FROMINT32X2(mult_01), AE_MOVF32X2_FROMINT32X2(mult_23)); \
  AE_MULF2P32X4RS(inp1_t, inp2_t, inp1_t, inp2_t, AE_MOVF32X2_FROMINT32X2(rs_mult_01), AE_MOVF32X2_FROMINT32X2(rs_mult_23)); \
  out = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(inp1_t), AE_MOVINT32X2_FROMF32X2(inp2_t)); \
  out = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out))); \
}

#define MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_X2_OUT16_ZB(out, out_a, inp1, inp2, inp1_a, inp2_a, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB(out, inp1, inp2, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off) \
  MPY_BY_QUANT_MULT_PER_CHAN_LR_MULT_X2X2_OUT16_ZB(out_a, inp1_a, inp2_a, mult_01, mult_23, ls_mult_01, ls_mult_23, rs_mult_01, rs_mult_23, out_off)

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32(prod, val, multiplier, lsh) {\
    prod = AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(val), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)));\
    prod = AE_MOVF32X2_FROMINT32X2(AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(prod), -lsh));\
}

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT32(prod0, prod1, val0, val1, multiplier, lsh) { \
    AE_MULF2P32X4RAS(prod0, prod1, val0, val1, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
    prod0 = AE_MOVF32X2_FROMINT32X2(AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(prod0), -lsh)); \
    prod1 = AE_MOVF32X2_FROMINT32X2(AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(prod1), -lsh)); \
}

#define MPY_BY_QUANT_MACC_ST_ONE_EXP_X2X2_OUT32(acc0, acc1, val0, val1, multiplier, lsh) { \
    ae_f32x2 valf0 = AE_MOVF32X2_FROMINT32X2(val0); \
    ae_f32x2 valf1 = AE_MOVF32X2_FROMINT32X2(val1); \
    AE_MULF2P32X4RAS(valf0, valf1, valf0, valf1, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
    AE_MULSF2P32X4RS(acc0, acc1, valf0, valf1, AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), lsh), AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), lsh)); \
}

#define MPY_BY_QUANT_MSUB_ST_ONE_EXP_X2X2_OUT32(acc0, acc1, val0, val1, multiplier, lsh) { \
    ae_f32x2 valf0 = AE_MOVF32X2_FROMINT32X2(val0); \
    ae_f32x2 valf1 = AE_MOVF32X2_FROMINT32X2(val1); \
    AE_MULF2P32X4RAS(valf0, valf1, valf0, valf1, AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
    AE_MULAF2P32X4RS(acc0, acc1, valf0, valf1, AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), lsh), AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), lsh)); \
}

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT32_ZB(out1, out2, inp1, inp2, multiplier, l_shift, out_off) \
  AE_MULF2P32X4RAS(out1, out2, AE_MOVF32X2_FROMINT32X2(inp1), AE_MOVF32X2_FROMINT32X2(inp2), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
  AE_MULF2P32X4RS(out1, out2, out1, out2, AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), l_shift), AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), l_shift)); \
  out1 = AE_SUB32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(out_off)), out1); \
  out2 = AE_SUB32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(out_off)), out2);

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2_OUT32_X2(prod1, prod2, val1, val2, multiplier1, multiplier2, lsh1, lsh2) {\
    AE_MULF2P32X4RAS(prod1, prod2, AE_MOVF32X2_FROMINT32X2(val1), AE_MOVF32X2_FROMINT32X2(val2), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier1)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier2)));\
    prod1 = AE_MOVF32X2_FROMINT32X2(AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(prod1), -lsh1)); \
    prod2 = AE_MOVF32X2_FROMINT32X2(AE_SRAA32SYMS(AE_MOVINT32X2_FROMF32X2(prod2), -lsh2)); \
}

#define MPY_BY_QUANT_MULT_ST_ONE_EXP_X2X2_OUT16_ZB(out1, inp1, inp2, multiplier, l_shift, out_off) \
  AE_MULF2P32X4RAS(inp1, inp2, inp1, inp2, AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier))); \
  AE_MULF2P32X4RS(inp1, inp2, inp1, inp2, AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), l_shift), AE_SLAA32S(AE_MOVF32X2_FROMINT32(AE_MOVDA32(0x80000000)), l_shift)); \
  out1 = AE_SAT16X4(AE_MOVINT32X2_FROMF32X2(inp1), AE_MOVINT32X2_FROMF32X2(inp2)); \
  out1 = AE_MOVINT16X4_FROMF16X4(AE_SUB16S(AE_MOVF16X4_FROMINT16X4(AE_MOVDA16(out_off)), AE_MOVF16X4_FROMINT16X4(out1)));

#define MPY_BY_QUANT_MULT_GT_ONE_X2_OUT32(y, x, multiplier, lsh) {\
    y = AE_SLAA32(x, lsh);\
    y = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(y), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(multiplier))));\
}

#define MPY_BY_QUANT_MULT_GT_ONE_X2X2_OUT32(y, z, l, m, multiplier, lsh) {\
    y = AE_SLAA32(l, lsh);\
    z = AE_SLAA32(m, lsh);\
    ae_f32x2 y_f32x2, z_f32x2;\
    AE_MULF2P32X4RAS(y_f32x2, z_f32x2, AE_MOVF32X2_FROMINT32X2(y), AE_MOVF32X2_FROMINT32X2(z), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(multiplier)));\
    y = AE_MOVINT32X2_FROMF32X2(y_f32x2);\
    z = AE_MOVINT32X2_FROMF32X2(z_f32x2);\
}

#define MPY_BY_QUANT_MULT_SLS_X2X2_OUT32_ALT(out1, out2, inp1, inp2, multiplier, left_shift, right_shift) \
{\
  int rsh_mul = (0XFFFFFFFF << (31 - right_shift)); \
  out1 = AE_MOVINT32X2_FROMF32X2(AE_SLAA32S(AE_MOVF32X2_FROMINT32X2(inp1), left_shift)); \
  out1 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(out1), AE_MOVF32X2_FROMINT32X2(AE_NEG32(SW_MOVDA32(multiplier))))); \
  out1 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RS(AE_MOVF32X2_FROMINT32X2(out1), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(rsh_mul)))); \
  out2 = AE_MOVINT32X2_FROMF32X2(AE_SLAA32S(AE_MOVF32X2_FROMINT32X2(inp2), left_shift)); \
  out2 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RAS(AE_MOVF32X2_FROMINT32X2(out2), AE_MOVF32X2_FROMINT32X2(AE_NEG32(SW_MOVDA32(multiplier))))); \
  out2 = AE_MOVINT32X2_FROMF32X2(AE_MULFP32X2RS(AE_MOVF32X2_FROMINT32X2(out2), AE_MOVF32X2_FROMINT32X2(SW_MOVDA32(rsh_mul)))); \
}

#endif /* #if TFLITE_SINGLE_ROUNDING */


#if XCHAL_HAVE_HIFI5S
#define MPY_BY_QUANT_MULT_ACC64_PER_CHAN_X2_OUT32_HIFI5S(out0, inp0, inp1, mult01, l_shift01) \
{ \
  ae_int16x4 d_red_multx4 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01))); \
  ae_int64 q0_l, q1_l; \
  AE_MULP48X16X2_L(q0_l, q1_l, inp0, inp1, d_red_multx4); \
  out0 = AE_ROUNDAV32X2F64SASYM(q0_l, q1_l, l_shift01); \
}

#define MPY_BY_QUANT_MULT_ACC64_PER_CHAN_X2X2_OUT16_HIFI5S(out0, inp0, inp1, inp2, inp3, mult01, mult23, l_shift01, l_shift23) \
{ \
  ae_int16x4 d_red_mult01x4 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01))); \
  ae_int16x4 d_red_mult23x4 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult23), AE_MOVF32X2_FROMINT32X2(mult23))); \
  ae_int64 q0_l, q1_l, q2_l, q3_l; \
  AE_MULP48X16X2_L(q0_l, q1_l, inp0, inp1, d_red_mult01x4); \
  AE_MULP48X16X2_L(q2_l, q3_l, inp2, inp3, d_red_mult23x4); \
  ae_int32x2 result0 = AE_ROUNDAV32X2F64SASYM(q0_l, q1_l, l_shift01); \
  ae_int32x2 result1 = AE_ROUNDAV32X2F64SASYM(q2_l, q3_l, l_shift23); \
  out0 = AE_SAT16X4(result0, result1); \
}

#define MPY_BY_QUANT_MULT_ACC64_X2_OUT32_HIFI5S(out0, inp0, inp1, mult, l_shift) \
{ \
  ae_int16x4 d_red_multx4 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult)))); \
  ae_int64 q0_l, q1_l; \
  AE_MULP48X16X2_L(q0_l, q1_l, inp0, inp1, d_red_multx4); \
  out0 = AE_ROUNDAV32X2F64SASYM(q0_l, q1_l, l_shift); \
}

#define MPY_BY_QUANT_MULT_ACC64_X2X2_OUT16_HIFI5S(out0, inp0, inp1, inp2, inp3, mult, l_shift) \
{ \
  ae_f32x2 mult_tmp = AE_MOVF32X2_FROMINT32X2(AE_MOVDA32X2(mult, mult)); \
  ae_int16x4 d_red_multx4 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(mult_tmp, mult_tmp)); \
  ae_int64 q0_l, q1_l, q2_l, q3_l; \
  AE_MULP48X16X2_L(q0_l, q1_l, inp0, inp1, d_red_multx4); \
  AE_MULP48X16X2_L(q2_l, q3_l, inp2, inp3, d_red_multx4); \
  ae_int32x2 result0 = AE_ROUNDAV32X2F64SASYM(q0_l, q1_l, l_shift); \
  ae_int32x2 result1 = AE_ROUNDAV32X2F64SASYM(q2_l, q3_l, l_shift); \
  out0 = AE_SAT16X4(result0, result1); \
}
#endif // XCHAL_HAVE_HIFI5S

/* 64-bit accumulator (actual range 48-bit) with 16-bit multiplier macros */
#define MPY_BY_QUANT_MULT_ACC64_OUT32(out0, inp0, mult, l_shift) \
{ \
  ae_f32x2 mult_tmp = AE_MOVF32X2_FROMINT32X2(AE_MOVDA32X2(mult, mult)); \
  ae_int32x2 d_red_mult = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(mult_tmp, mult_tmp))); \
  ae_f32x2 d_red_mult_l16 = AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(mult_tmp, mult_tmp));  \
  ae_int32x2 d_inp0_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32F64SASYM(AE_MOVF64_FROMINT64(inp0))); \
  ae_f64 q0_l; \
  q0_l = AE_MOVF64_FROMINT64(AE_MUL32S_LL(d_red_mult, AE_MOVINT32X2_FROMINT64(inp0))); \
  AE_MULAF32S_LL(q0_l, d_red_mult_l16, AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp0_h, 15))); \
  q0_l = AE_MOVF64_FROMINT64(AE_SLAA64(AE_MOVINT64_FROMF64(q0_l), (l_shift + 17))); \
  out0 = AE_MOVINT32X2_FROMF32X2(AE_ROUND32F64SASYM(q0_l)); \
}

#define MPY_BY_QUANT_MULT_ACC64_X2_OUT32(out0, inp0, inp1, mult, l_shift) \
{ \
  ae_int32x2 d_red_mult = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult)),      AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult))))); \
  ae_int32x2 d_red_mult_l16 = AE_MOVINT32X2_FROMF32X2(AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult)), AE_MOVF32X2_FROMINT32(AE_MOVDA32(mult)))));  \
  ae_int32x2 d_inp01_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp0), AE_MOVF64_FROMINT64(inp1))); \
  ae_int64 q0_l, q1_l; \
  AE_MUL32X2S_HH_LL(q0_l, q1_l, d_red_mult, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp0), AE_MOVINT32X2_FROMINT64(inp1))); \
  ae_f64 temp_q0 = AE_MOVF64_FROMINT64(q0_l); \
  ae_f64 temp_q1 = AE_MOVF64_FROMINT64(q1_l); \
  ae_f32x2 temp_mult = AE_MOVF32X2_FROMINT32X2(d_red_mult_l16); \
  ae_f32x2 temp_inp = AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp01_h,15)); \
  AE_MULAFP32X2S_HH_LL(temp_q0, temp_q1, temp_mult, temp_inp); \
  temp_q0 = AE_SLAA64S(temp_q0, (l_shift + 17)); \
  temp_q1 = AE_SLAA64S(temp_q1, (l_shift + 17)); \
  out0 = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(temp_q0,temp_q1)); \
}

#define MPY_BY_QUANT_MULT_ACC64_X2X2_OUT16(out0, inp0, inp1, inp2, inp3, mult, l_shift) \
{ \
  ae_f32x2 mult_tmp = AE_MOVF32X2_FROMINT32X2(AE_MOVDA32X2(mult, mult)); \
  ae_int32x2 d_red_mult = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(mult_tmp, mult_tmp))); \
  ae_int32x2 d_red_mult_l16 = AE_MOVINT32X2_FROMF32X2(AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(mult_tmp, mult_tmp)));  \
  ae_int32x2 d_inp01_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp0), AE_MOVF64_FROMINT64(inp1))); \
  ae_int32x2 d_inp23_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp2), AE_MOVF64_FROMINT64(inp3))); \
  ae_int64 q0_l, q1_l, q2_l, q3_l; \
  ae_int32x2 out32_0, out32_1; \
  AE_MUL32X2S_HH_LL(q0_l, q1_l, d_red_mult, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp0), AE_MOVINT32X2_FROMINT64(inp1))); \
  ae_f64 temp_q0 = AE_MOVF64_FROMINT64(q0_l); \
  ae_f64 temp_q1 = AE_MOVF64_FROMINT64(q1_l); \
  AE_MULAFP32X2S_HH_LL(temp_q0, temp_q1, AE_MOVF32X2_FROMINT32X2(d_red_mult_l16), AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp01_h, 15))); \
  AE_MUL32X2S_HH_LL(q2_l, q3_l, d_red_mult, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp2), AE_MOVINT32X2_FROMINT64(inp3))); \
  ae_f64 temp_q2 = AE_MOVF64_FROMINT64(q2_l); \
  ae_f64 temp_q3 = AE_MOVF64_FROMINT64(q3_l); \
  AE_MULAFP32X2S_HH_LL(temp_q2, temp_q3, AE_MOVF32X2_FROMINT32X2(d_red_mult_l16), AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp23_h, 15))); \
  out32_0 = AE_TRUNCA32X2F64S(AE_MOVINT64_FROMF64(temp_q0), AE_MOVINT64_FROMF64(temp_q1), l_shift + 33); \
  out32_1 = AE_TRUNCA32X2F64S(AE_MOVINT64_FROMF64(temp_q2), AE_MOVINT64_FROMF64(temp_q3), l_shift + 33); \
  out0 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))) ; \
}

#define MPY_BY_QUANT_MULT_ACC64_PER_CHAN_X2_OUT32(out0, inp0, inp1, mult01, l_shift01) \
{ \
  ae_int32x2 d_red_mult01 = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01)))); \
  ae_int32x2 d_red_mult01_l16 = AE_MOVINT32X2_FROMF32X2(AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01)))); \
  ae_int32x2 d_inp01_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp0), AE_MOVF64_FROMINT64(inp1))); \
  ae_int64 q0_l, q1_l; \
  AE_MUL32X2S_HH_LL(q0_l, q1_l, d_red_mult01, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp0), AE_MOVINT32X2_FROMINT64(inp1))); \
  ae_f64 temp_q0_l = AE_MOVF64_FROMINT64(q0_l); \
  ae_f64 temp_q1_l = AE_MOVF64_FROMINT64(q1_l); \
  AE_MULAFP32X2S_HH_LL(temp_q0_l, temp_q1_l, AE_MOVF32X2_FROMINT32X2(d_red_mult01_l16), AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp01_h, 15))); \
  q0_l = AE_MOVINT64_FROMF64(temp_q0_l); \
  q1_l = AE_MOVINT64_FROMF64(temp_q1_l); \
  q0_l = AE_SLAA64(q0_l, (AE_MOVAD32_H(l_shift01)+17)); \
  q1_l = AE_SLAA64(q1_l, (AE_MOVAD32_L(l_shift01)+17)); \
  out0 = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(q0_l), AE_MOVF64_FROMINT64(q1_l))); \
}

#ifdef AE_TRUNCAV32X2F64S
#define MPY_BY_QUANT_MULT_ACC64_PER_CHAN_X2X2_OUT16(out0, inp0, inp1, inp2, inp3, mult01, mult23, l_shift01, l_shift23) \
{ \
  ae_int32x2 d_red_mult01 = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01)))); \
  ae_int32x2 d_red_mult01_l16 = AE_MOVINT32X2_FROMF32X2(AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult01), AE_MOVF32X2_FROMINT32X2(mult01)))); \
  ae_int32x2 d_red_mult23 = AE_SEXT32X2D16_10(AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult23), AE_MOVF32X2_FROMINT32X2(mult23)))); \
  ae_int32x2 d_red_mult23_l16 = AE_MOVINT32X2_FROMF32X2(AE_CVT32X2F16_10(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(mult23), AE_MOVF32X2_FROMINT32X2(mult23)))); \
  ae_int32x2 d_inp01_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp0), AE_MOVF64_FROMINT64(inp1))); \
  ae_int32x2 d_inp23_h = AE_MOVINT32X2_FROMF32X2(AE_ROUND32X2F64SASYM(AE_MOVF64_FROMINT64(inp2), AE_MOVF64_FROMINT64(inp3))); \
  ae_int64 q0_l, q1_l, q2_l, q3_l; \
  AE_MUL32X2S_HH_LL(q0_l, q1_l, d_red_mult01, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp0), AE_MOVINT32X2_FROMINT64(inp1)));      \
  ae_f64 q0_l_temp, q1_l_temp, q2_l_temp, q3_l_temp; \
  q0_l_temp = AE_MOVF64_FROMINT64(q0_l); \
  q1_l_temp = AE_MOVF64_FROMINT64(q1_l); \
  AE_MULAFP32X2S_HH_LL(q0_l_temp, q1_l_temp, AE_MOVF32X2_FROMINT32X2(d_red_mult01_l16), AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp01_h, 15))); \
  q0_l = AE_MOVINT64_FROMF64(q0_l_temp); \
  q1_l = AE_MOVINT64_FROMF64(q1_l_temp); \
  AE_MUL32X2S_HH_LL(q2_l, q3_l, d_red_mult23, AE_SEL32_LL(AE_MOVINT32X2_FROMINT64(inp2), AE_MOVINT32X2_FROMINT64(inp3)));      \
  q2_l_temp = AE_MOVF64_FROMINT64(q2_l); \
  q3_l_temp = AE_MOVF64_FROMINT64(q3_l); \
  AE_MULAFP32X2S_HH_LL(q2_l_temp, q3_l_temp, AE_MOVF32X2_FROMINT32X2(d_red_mult23_l16), AE_MOVF32X2_FROMINT32X2(AE_SLAI32(d_inp23_h, 15))); \
  q2_l = AE_MOVINT64_FROMF64(q2_l_temp); \
  q3_l = AE_MOVINT64_FROMF64(q3_l_temp); \
  ae_int32x2 out32_0 = AE_TRUNCAV32X2F64S(q0_l, q1_l, AE_MOVAD32_H(l_shift01)); \
  ae_int32x2 out32_1 = AE_TRUNCAV32X2F64S(q2_l, q3_l, AE_MOVAD32_H(l_shift23)); \
  out0 = AE_MOVINT16X4_FROMF16X4(AE_ROUND16X4F32SASYM(AE_MOVF32X2_FROMINT32X2(out32_0), AE_MOVF32X2_FROMINT32X2(out32_1))); \
}
#endif

#endif /* #ifndef __XA_NNLIB_QUANT_MACROS_HIFI5_H__ */
