/*******************************************************************************
* Copyright (c) 2018-2026 Cadence Design Systems, Inc.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to use this Software with Cadence processor cores only and
* not with any other processors and platforms, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

******************************************************************************/
#include "xa_nnlib_common_fpu.h"
#include "xa_nnlib_common.h"
#include "xa_nnlib_common_macros_hifi5.h"
#include "xa_nn_transpose_conv_state.h"
#include <string.h>

#if NO_AGGR_FLOAT_OPT
#define _MADD_SX2(accum0, temp0, d0, d1) \
  temp0 = MUL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d0), AE_MOVXTFLOATX2_FROMXTFLOAT(d1)); \
  accum0 = AE_MOVXTFLOAT_FROMXTFLOATX2(ADD_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(accum0), temp0));
#endif /* NO_AGGR_FLOAT_OPT */

#if !HAVE_VFPU
DISCARD_FUN_FOR_NONVOID_RETURN(WORD32, xa_nn_transpose_conv_f32, (FLOAT32* output_data,
            const FLOAT32* input_data,
            const FLOAT32* filter_data,
            const FLOAT32* bias_data,
            int stride_width, int stride_height,
            int pad_width, int pad_height,
            int input_depth, int output_depth,
            int input_height, int input_width,
            int filter_height, int filter_width,
            int output_height, int output_width,
            int num_elements, int num_groups,
            void* scratch_buffer))
#else
#if NO_AGGR_FLOAT_OPT
static inline void tconv2d_f32(FLOAT32* output_data,
    const FLOAT32* input_data,
    const FLOAT32* filter_data,
    const FLOAT32* bias_data,
    int stride_width, int stride_height,
    int pad_width, int pad_height,
    int input_depth, int output_depth,
    int input_height, int input_width,
    int filter_height, int filter_width,
    int output_height, int output_width,
    int num_elements,
    FLOAT32* scratch_buffer)
{
  /* scratch memory is as big as output buffer, and stores 1 element per output */
  memset(scratch_buffer, 0, num_elements*sizeof(FLOAT32));
  ae_int32 *pscratch32 = (ae_int32 *)scratch_buffer;

  int stride1 = filter_height*filter_width*input_depth*sizeof(FLOAT32);

  if(input_data && filter_data && output_data && scratch_buffer &&
    (((unsigned int)input_data&0x7)==0) && (((unsigned int)filter_data&0x7)==0) && (((unsigned int)output_data&0x7) == 0) &&
    (((unsigned int)scratch_buffer&0xF) == 0) && ((input_depth&0x7)==0) && ((filter_height*filter_width&0x3)==0) && ((output_depth&0x3)==0))
  {
    for (int in_y = 0; in_y < input_height; ++in_y)
    {
      for (int in_x = 0; in_x < input_width; ++in_x)
      {
        const int out_x_orig = in_x*stride_width - pad_width;
        const int out_y_orig = in_y*stride_height - pad_height;
        int filt_x_min = -out_x_orig;
        int filt_x_max = output_width - out_x_orig;
        int filt_y_min = -out_y_orig;
        int filt_y_max = output_height - out_y_orig;
        filt_x_min = (filt_x_min < filter_width) ? filt_x_min : filter_width;
        filt_x_min = (filt_x_min < 0) ? 0 : filt_x_min;
        filt_x_max = (filt_x_max < filter_width) ? filt_x_max : filter_width;
        filt_x_max = (filt_x_max < 0) ? 0 : filt_x_max;
        filt_y_min = (filt_y_min < filter_height) ? filt_y_min : filter_height;
        filt_y_min = (filt_y_min < 0) ? 0 : filt_y_min;
        filt_y_max = (filt_y_max < filter_height) ? filt_y_max : filter_height;
        filt_y_max = (filt_y_max < 0) ? 0 : filt_y_max;
        xtfloatx4 * __restrict__ pinp = (xtfloatx4 *)((FLOAT32*)&input_data[in_y*input_width*input_depth+in_x*input_depth]);

        xtfloatx2 *p_inp_align = (xtfloatx2 *)pinp;
      
        int in_channel;

        xtfloatx2 _xtfloatx2_temp_00 = ZERO_SX2();
        xtfloatx2 _xtfloatx2_temp_01 = ZERO_SX2();
        xtfloatx2 _xtfloatx2_temp_02 = ZERO_SX2();
        xtfloatx2 _xtfloatx2_temp_03 = ZERO_SX2();
        for (in_channel=0 ; in_channel < (input_depth & ~0x3); in_channel+=4)
        {
          xtfloatx2 d_inp, d_inp1;
          AE_LSX2X2_IP(d_inp, d_inp1, pinp, 4*sizeof(FLOAT32));
          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;
              int out_y = out_y_orig + filter_y;
              xtfloatx4* __restrict__ pscratch_src = (xtfloatx4 *)((FLOAT32*)&pscratch32[out_y*output_width*output_depth+out_x*output_depth]);
              xtfloatx4* __restrict__ pfilt = (xtfloatx4 *)((FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + in_channel]);

              int out_channel = 0;

              for (; out_channel < (output_depth&~0x7); out_channel+=8)
              {
                xtfloatx2 d_fil0, d_fil10;
                xtfloatx2 d_fil1, d_fil11;
                xtfloatx2 d_fil2, d_fil12;
                xtfloatx2 d_fil3, d_fil13;
                xtfloatx2 d_fil4, d_fil14;
                xtfloatx2 d_fil5, d_fil15;
                xtfloatx2 d_fil6, d_fil16;
                xtfloatx2 d_fil7, d_fil17;
                xtfloatx2 d_scr0;
                xtfloatx2 d_scr1;
                xtfloatx2 d_scr2;
                xtfloatx2 d_scr3;
                AE_LSX2X2_I(d_scr0, d_scr1, pscratch_src, 0);
                AE_LSX2X2_I(d_scr2, d_scr3, pscratch_src, 16);
                AE_LSX2X2_XP(d_fil0, d_fil10, pfilt, stride1);
                AE_LSX2X2_XP(d_fil1, d_fil11, pfilt, stride1);
                AE_LSX2X2_XP(d_fil2, d_fil12, pfilt, stride1);
                AE_LSX2X2_XP(d_fil3, d_fil13, pfilt, stride1);
                AE_LSX2X2_XP(d_fil4, d_fil14, pfilt, stride1);
                AE_LSX2X2_XP(d_fil5, d_fil15, pfilt, stride1);
                AE_LSX2X2_XP(d_fil6, d_fil16, pfilt, stride1);
                AE_LSX2X2_XP(d_fil7, d_fil17, pfilt, stride1);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp)), AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp)), AE_SEL32_HH_SX2(d_fil0, d_fil1), AE_SEL32_HH_SX2(d_fil2, d_fil3));
                MUL_SX2X2(_xtfloatx2_temp_02, _xtfloatx2_temp_03, AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp)), AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp)), AE_SEL32_HH_SX2(d_fil4, d_fil5), AE_SEL32_HH_SX2(d_fil6, d_fil7));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                ADD_SX2X2(d_scr2, d_scr3, d_scr2, d_scr3, _xtfloatx2_temp_02, _xtfloatx2_temp_03);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp)), AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp)), AE_SEL32_LL_SX2(d_fil0, d_fil1), AE_SEL32_LL_SX2(d_fil2, d_fil3));
                MUL_SX2X2(_xtfloatx2_temp_02, _xtfloatx2_temp_03, AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp)), AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp)), AE_SEL32_LL_SX2(d_fil4, d_fil5), AE_SEL32_LL_SX2(d_fil6, d_fil7));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                ADD_SX2X2(d_scr2, d_scr3, d_scr2, d_scr3, _xtfloatx2_temp_02, _xtfloatx2_temp_03);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp1)), AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp1)), AE_SEL32_HH_SX2(d_fil10, d_fil11), AE_SEL32_HH_SX2(d_fil12, d_fil13));
                MUL_SX2X2(_xtfloatx2_temp_02, _xtfloatx2_temp_03, AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp1)), AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp1)), AE_SEL32_HH_SX2(d_fil14, d_fil15), AE_SEL32_HH_SX2(d_fil16, d_fil17));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                ADD_SX2X2(d_scr2, d_scr3, d_scr2, d_scr3, _xtfloatx2_temp_02, _xtfloatx2_temp_03);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp1)), AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp1)), AE_SEL32_LL_SX2(d_fil10, d_fil11), AE_SEL32_LL_SX2(d_fil12, d_fil13));
                MUL_SX2X2(_xtfloatx2_temp_02, _xtfloatx2_temp_03, AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp1)), AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp1)), AE_SEL32_LL_SX2(d_fil14, d_fil15), AE_SEL32_LL_SX2(d_fil16, d_fil17));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                ADD_SX2X2(d_scr2, d_scr3, d_scr2, d_scr3, _xtfloatx2_temp_02, _xtfloatx2_temp_03);

                AE_SSX2X2_IP(d_scr0, d_scr1, pscratch_src, 16);
                AE_SSX2X2_IP(d_scr2, d_scr3, pscratch_src, 16);
              }
              xtfloatx2 *pscratchx2_src = (xtfloatx2 *)pscratch_src;
              for (; out_channel < output_depth; out_channel+=2)
              {
                xtfloatx2 d_scr0;
                xtfloatx2 d_fil0, d_fil10;
                xtfloatx2 d_fil1, d_fil11;
                d_scr0 = AE_LSX2I(pscratchx2_src, 0);
                AE_LSX2X2_XP(d_fil0, d_fil10, pfilt, stride1);
                AE_LSX2X2_XP(d_fil1, d_fil11, pfilt, stride1);

                _xtfloatx2_temp_00 = MUL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp)), AE_SEL32_HH_SX2(d_fil0, d_fil1));
                d_scr0 = ADD_SX2(d_scr0, _xtfloatx2_temp_00);
                _xtfloatx2_temp_00 = MUL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp)), AE_SEL32_LL_SX2(d_fil0, d_fil1));
                d_scr0 = ADD_SX2(d_scr0, _xtfloatx2_temp_00);
                _xtfloatx2_temp_00 = MUL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(HIGH_S(d_inp1)), AE_SEL32_HH_SX2(d_fil10, d_fil11));
                d_scr0 = ADD_SX2(d_scr0, _xtfloatx2_temp_00);
                _xtfloatx2_temp_00 = MUL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(LOW_S(d_inp1)), AE_SEL32_LL_SX2(d_fil10, d_fil11));
                d_scr0 = ADD_SX2(d_scr0, _xtfloatx2_temp_00);

                AE_SSX2IP(d_scr0, pscratchx2_src, 8);
              }
              pscratch_src = (xtfloatx4*)pscratchx2_src;
            }
          }
        }
        xtfloat *pt_inp_align = (xtfloat *)p_inp_align;
        for (in_channel=0 ; in_channel < (input_depth & 0x3); in_channel++)
        {
          xtfloat d_inp;
          XT_LSIP(d_inp, pt_inp_align, 4);
          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;
              int out_y = out_y_orig + filter_y;
              xtfloatx4* __restrict__ pscratch_src = (xtfloatx4 *)((FLOAT32*)&pscratch32[out_y*output_width*output_depth+out_x*output_depth]);
              FLOAT32* __restrict__ pfilt = (FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + in_channel];

              ae_valignx2 align_scr = AE_LA128_PP(pscratch_src);
              ae_valignx2 align_out;
              int out_channel = 0;

              for (; out_channel < (output_depth&~0x3); out_channel+=4)
              {
                xtfloat   d_fil0;
                xtfloat   d_fil1;
                xtfloat   d_fil2;
                xtfloat   d_fil3;
                xtfloatx2 d_scr0;
                xtfloatx2 d_scr1;

                AE_LASX2X2_IP(d_scr0, d_scr1, align_scr, pscratch_src);
                XT_LSXP(d_fil0, pfilt, stride1);
                XT_LSXP(d_fil1, pfilt, stride1);
                XT_LSXP(d_fil2, pfilt, stride1);
                XT_LSXP(d_fil3, pfilt, stride1);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(d_inp), AE_MOVXTFLOATX2_FROMXTFLOAT(d_inp), AE_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil0), AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil1)), AE_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil2), AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil3)));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                pscratch_src -= 4;
                AE_SASX2X2_IP(d_scr0, d_scr1, align_out, pscratch_src);
              }
              AE_SA128POS_FP(align_out, pscratch_src);

              xtfloat *pscratch_src_t = (xtfloat *)pscratch_src;
              for (; out_channel < output_depth; out_channel++)
              {
                xtfloat   d_fil;
                xtfloat d_scr0;
                d_scr0 = XT_LSI(pscratch_src_t, 0);
                XT_LSXP(d_fil, pfilt, stride1);
                _MADD_SX2(d_scr0, _xtfloatx2_temp_00, d_inp, d_fil);
                XT_SSIP(HIGH_S(AE_MOVXTFLOATX2_FROMXTFLOAT(d_scr0)), pscratch_src_t, 4);
              }
              pscratch_src = (xtfloatx4*)pscratch_src_t;
            }
          }
        }
      }
    }
  }
  else
  {
    for (int in_y = 0; in_y < input_height; ++in_y)
    {
      for (int in_x = 0; in_x < input_width; ++in_x)
      {
        const int out_x_orig = in_x*stride_width - pad_width;
        const int out_y_orig = in_y*stride_height - pad_height;
        int filt_x_min = -out_x_orig;
        int filt_x_max = output_width - out_x_orig;
        int filt_y_min = -out_y_orig;
        int filt_y_max = output_height - out_y_orig;
        filt_x_min = (filt_x_min < filter_width) ? filt_x_min : filter_width;
        filt_x_min = (filt_x_min < 0) ? 0 : filt_x_min;
        filt_x_max = (filt_x_max < filter_width) ? filt_x_max : filter_width;
        filt_x_max = (filt_x_max < 0) ? 0 : filt_x_max;
        filt_y_min = (filt_y_min < filter_height) ? filt_y_min : filter_height;
        filt_y_min = (filt_y_min < 0) ? 0 : filt_y_min;
        filt_y_max = (filt_y_max < filter_height) ? filt_y_max : filter_height;
        filt_y_max = (filt_y_max < 0) ? 0 : filt_y_max;
        FLOAT32 * __restrict__ pinp =  (FLOAT32*)&input_data[in_y*input_width*input_depth+in_x*input_depth];

        xtfloat *p_inp_align = (xtfloat *)pinp;
      
        int in_channel;

        xtfloatx2 _xtfloatx2_temp_00 = ZERO_SX2();
        xtfloatx2 _xtfloatx2_temp_01 = ZERO_SX2();
        for (in_channel=0 ; in_channel < (input_depth ); in_channel++)
        {
          xtfloat d_inp;
          XT_LSIP(d_inp, p_inp_align, 4);
          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;
              int out_y = out_y_orig + filter_y;
              xtfloatx4* __restrict__ pscratch_src = (xtfloatx4 *) ((FLOAT32*)&pscratch32[out_y*output_width*output_depth+out_x*output_depth]);
              FLOAT32* __restrict__ pfilt = (FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + in_channel];

              ae_valignx2 align_scr = AE_LA128_PP(pscratch_src);
              ae_valignx2 align_out;
              int out_channel = 0;

              for (; out_channel < (output_depth&~0x3); out_channel+=4)
              {
                xtfloat   d_fil0;
                xtfloat   d_fil1;
                xtfloat   d_fil2;
                xtfloat   d_fil3;
                xtfloatx2 d_scr0;
                xtfloatx2 d_scr1;

                AE_LASX2X2_IP(d_scr0, d_scr1, align_scr, pscratch_src);
                XT_LSXP(d_fil0, pfilt, stride1);
                XT_LSXP(d_fil1, pfilt, stride1);
                XT_LSXP(d_fil2, pfilt, stride1);
                XT_LSXP(d_fil3, pfilt, stride1);

                MUL_SX2X2(_xtfloatx2_temp_00, _xtfloatx2_temp_01, AE_MOVXTFLOATX2_FROMXTFLOAT(d_inp), AE_MOVXTFLOATX2_FROMXTFLOAT(d_inp), AE_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil0), AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil1)), AE_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil2), AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil3)));
                ADD_SX2X2(d_scr0, d_scr1, d_scr0, d_scr1, _xtfloatx2_temp_00, _xtfloatx2_temp_01);
                pscratch_src -= 4;
                AE_SASX2X2_IP(d_scr0, d_scr1, align_out, pscratch_src);
              }
              AE_SA128POS_FP(align_out, pscratch_src);

              xtfloat *pscratch_src_t = (xtfloat *)pscratch_src;
              for (; out_channel < output_depth; out_channel++)
              {
                xtfloat   d_fil;
                xtfloat d_scr0;
                d_scr0 = XT_LSI(pscratch_src_t, 0);
                XT_LSXP(d_fil, pfilt, stride1);
                _MADD_SX2(d_scr0, _xtfloatx2_temp_00, d_inp, d_fil);
                XT_SSIP(HIGH_S(AE_MOVXTFLOATX2_FROMXTFLOAT(d_scr0)), pscratch_src_t, 4);
              }
              pscratch_src = (xtfloatx4*)pscratch_src_t;
            }
          }
        }
      }
    }
  }
  if(bias_data)
  {
    xtfloat *pbias = (xtfloat*)((FLOAT32*)bias_data);

    for (int out_channel = 0; out_channel < output_depth; ++out_channel)
    {
      xtfloat acc;
      xtfloat dbias;
      xtfloat *pscratch = (xtfloat *)((FLOAT32*)&pscratch32[out_channel]);
      FLOAT32 *pout = (FLOAT32*)&output_data[out_channel];
      XT_LSIP(dbias, pbias, sizeof(FLOAT32));

      for (int i = 0; i < (output_height*output_width); i++)
      {
        XT_LSXP(acc, pscratch, output_depth*sizeof(FLOAT32));
        XT_SSXP(ADD_S(acc, dbias), pout, output_depth*sizeof(FLOAT32));
      }
    }
  }
  else
  {
    xtfloat *pscratch = (xtfloat*)scratch_buffer;
    FLOAT32 *pout = (FLOAT32*)output_data;
    for (int i = 0; i < output_height*output_width; i++)
    {
      for (int out_channel = 0; out_channel < output_depth; ++out_channel)
      {
        xtfloat acc;
        XT_LSIP(acc, pscratch, sizeof(FLOAT32));
        XT_SSIP((acc), pout, sizeof(FLOAT32));
      }
    }
  }    
}
#else
static inline void tconv2d_f32(FLOAT32* output_data,
  const FLOAT32* input_data,
  const FLOAT32* filter_data,
  const FLOAT32* bias_data,
  int stride_width, int stride_height,
  int pad_width, int pad_height,
  int input_depth, int output_depth,
  int input_height, int input_width,
  int filter_height, int filter_width,
  int output_height, int output_width,
  int num_elements,
  FLOAT32* scratch_buffer)
{
  /* scratch memory is twice as big as output buffer, and stores 2 elements per output to allow parallel mac operations */
  memset(scratch_buffer, 0, 2*num_elements*sizeof(FLOAT32));
  ae_int64 *pscratch64 = (ae_int64 *)scratch_buffer;

  int stride1 = filter_height*filter_width*input_depth*sizeof(FLOAT32);

  if(input_data && filter_data && output_data && scratch_buffer &&
            (((unsigned int)input_data&0x7)==0) && (((unsigned int)filter_data&0x7)==0) && (((unsigned int)output_data&0x7) == 0) &&
            (((unsigned int)scratch_buffer&0xF) == 0) && ((input_depth&0x7)==0) && ((filter_height*filter_width&0x3)==0) && ((output_depth&0x1)==0))
  {
    for (int in_y = 0; in_y < input_height; ++in_y)
    {
      for (int in_x = 0; in_x < input_width; ++in_x)
      {
        const int out_x_orig = in_x*stride_width - pad_width;
        const int out_y_orig = in_y*stride_height - pad_height;
        int filt_x_min = -out_x_orig; 
        int filt_x_max = output_width - out_x_orig; 
        int filt_y_min = -out_y_orig; 
        int filt_y_max = output_height - out_y_orig; 
        filt_x_min = (filt_x_min < filter_width) ? filt_x_min : filter_width;
        filt_x_min = (filt_x_min < 0) ? 0 : filt_x_min;
        filt_x_max = (filt_x_max < filter_width) ? filt_x_max : filter_width;
        filt_x_max = (filt_x_max < 0) ? 0 : filt_x_max;
        filt_y_min = (filt_y_min < filter_height) ? filt_y_min : filter_height;
        filt_y_min = (filt_y_min < 0) ? 0 : filt_y_min;
        filt_y_max = (filt_y_max < filter_height) ? filt_y_max : filter_height;
        filt_y_max = (filt_y_max < 0) ? 0 : filt_y_max;
        xtfloatx4 * __restrict__ pinp =  (xtfloatx4 *)((FLOAT32*)&input_data[in_y*input_width*input_depth+in_x*input_depth]);

        for (int in_channel = 0; in_channel < input_depth; in_channel+=4)
        {
          xtfloatx2 d_inp, d_inp1;
          AE_LSX2X2_IP(d_inp, d_inp1, pinp, 4*sizeof(FLOAT32));

          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;//out_x_origin + filter_x;
              int out_y = out_y_orig + filter_y;//out_y_origin + filter_y;
              xtfloatx4* __restrict__ pscratch_src = (xtfloatx4 *)((FLOAT32*)&pscratch64[out_y*output_width*output_depth+out_x*output_depth]);
              xtfloatx4 * __restrict__ pfilt = (xtfloatx4 *)((FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + in_channel]);

              for (int out_channel = 0; out_channel < output_depth>>3; ++out_channel)
              {
                xtfloatx2 d_fil0, d_fil1, d_fil2, d_fil3;
                xtfloatx2 d_fil10, d_fil11, d_fil12, d_fil13;
                xtfloatx2 d_scr0, d_scr1, d_scr2, d_scr3;
                xtfloatx2 d_fil4, d_fil5, d_fil6, d_fil7;
                xtfloatx2 d_fil14, d_fil15, d_fil16, d_fil17;
                xtfloatx2 d_scr4, d_scr5, d_scr6, d_scr7;

                AE_LSX2X2_I(d_scr0, d_scr1, pscratch_src, 0);
                AE_LSX2X2_I(d_scr2, d_scr3, pscratch_src, 16);
                AE_LSX2X2_I(d_scr4, d_scr5, pscratch_src, 32);
                AE_LSX2X2_I(d_scr6, d_scr7, pscratch_src, 48);

                AE_LSX2X2_XP(d_fil0, d_fil10, pfilt, stride1);
                AE_LSX2X2_XP(d_fil1, d_fil11, pfilt, stride1);
                AE_LSX2X2_XP(d_fil2, d_fil12, pfilt, stride1);
                AE_LSX2X2_XP(d_fil3, d_fil13, pfilt, stride1);
                AE_LSX2X2_XP(d_fil4, d_fil14, pfilt, stride1);
                AE_LSX2X2_XP(d_fil5, d_fil15, pfilt, stride1);
                AE_LSX2X2_XP(d_fil6, d_fil16, pfilt, stride1);
                AE_LSX2X2_XP(d_fil7, d_fil17, pfilt, stride1);
                
                MADDQ_S(d_scr0, d_scr1, d_fil0, d_fil1, d_inp);
                MADDQ_S(d_scr2, d_scr3, d_fil2, d_fil3, d_inp);
                MADDQ_S(d_scr4, d_scr5, d_fil4, d_fil5, d_inp);
                MADDQ_S(d_scr6, d_scr7, d_fil6, d_fil7, d_inp);
                MADDQ_S(d_scr0, d_scr1, d_fil10, d_fil11, d_inp1);
                MADDQ_S(d_scr2, d_scr3, d_fil12, d_fil13, d_inp1);
                MADDQ_S(d_scr4, d_scr5, d_fil14, d_fil15, d_inp1);
                MADDQ_S(d_scr6, d_scr7, d_fil16, d_fil17, d_inp1);

                AE_SSX2X2_I(d_scr0, d_scr1, pscratch_src, 0);
                AE_SSX2X2_I(d_scr2, d_scr3, pscratch_src, 16);
                AE_SSX2X2_I(d_scr4, d_scr5, pscratch_src, 32);
                AE_SSX2X2_I(d_scr6, d_scr7, pscratch_src, 48);
                pscratch_src = (xtfloatx4*)((FLOAT32*)pscratch_src + 16);
              }
              xtfloatx2 *  px2_filt = (xtfloatx2 *)pfilt;
              xtfloatx2 *  pscratch_srcx2 = (xtfloatx2 *)pscratch_src;
              for (int out_channel = 0; out_channel < (output_depth&0x7); ++out_channel)
              {
                xtfloatx2 d_fil, d_fil1;
                XT_LSX2XP(d_fil, px2_filt, 8);
                XT_LSX2XP(d_fil1, px2_filt, stride1-8);
                xtfloatx2 d_scr = XT_LSX2I(pscratch_srcx2, 0);
                d_scr = ADD_SX2(d_scr, MUL_SX2(d_inp, d_fil));
                d_scr = ADD_SX2(d_scr, MUL_SX2(d_inp1, d_fil1));
                XT_SSX2IP(d_scr, pscratch_srcx2, 2*sizeof(FLOAT32));
              }
              pfilt = (xtfloatx4 *)px2_filt;
            }
          }
        }
      }
    }
  } 
  else
  {
    for (int in_y = 0; in_y < input_height; ++in_y)
    {
      for (int in_x = 0; in_x < input_width; ++in_x)
      {
        const int out_x_orig = in_x*stride_width - pad_width;
        const int out_y_orig = in_y*stride_height - pad_height;
        int filt_x_min = -out_x_orig; 
        int filt_x_max = output_width - out_x_orig; 
        int filt_y_min = -out_y_orig; 
        int filt_y_max = output_height - out_y_orig; 
        filt_x_min = (filt_x_min < filter_width) ? filt_x_min : filter_width;
        filt_x_min = (filt_x_min < 0) ? 0 : filt_x_min;
        filt_x_max = (filt_x_max < filter_width) ? filt_x_max : filter_width;
        filt_x_max = (filt_x_max < 0) ? 0 : filt_x_max;
        filt_y_min = (filt_y_min < filter_height) ? filt_y_min : filter_height;
        filt_y_min = (filt_y_min < 0) ? 0 : filt_y_min;
        filt_y_max = (filt_y_max < filter_height) ? filt_y_max : filter_height;
        filt_y_max = (filt_y_max < 0) ? 0 : filt_y_max;
        FLOAT32 * __restrict__ pinp =  (FLOAT32*)&input_data[in_y*input_width*input_depth+in_x*input_depth];

        ae_valignx2 d_inp_align;
        xtfloatx4 *p_inp_align = (xtfloatx4 *)pinp;
        d_inp_align = AE_LA128_PP(p_inp_align);
        
        int in_channel;
        for (in_channel = 0; in_channel < (input_depth >> 2); in_channel++)
        {
          xtfloatx2 d_inp, d_inp1;

          AE_LASX2X2_IP(d_inp, d_inp1, d_inp_align, p_inp_align);

          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;
              int out_y = out_y_orig + filter_y;
              xtfloatx2* __restrict__ pscratch_src = (xtfloatx2 *)((FLOAT32*)&pscratch64[out_y*output_width*output_depth+out_x*output_depth]);
              xtfloatx4* __restrict__ pfilt = (xtfloatx4 *)((FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + (in_channel << 2)]);

              ae_valignx2 filt_align;

              int out_channel = 0;
              for (out_channel = 0; out_channel < (output_depth >> 2) ; ++out_channel)
              {
                xtfloatx2 d_fil0, d_fil1, d_fil2, d_fil3;
                xtfloatx2 d_fil10, d_fil11, d_fil12, d_fil13;
                xtfloatx2 d_scr0, d_scr1, d_scr2, d_scr3;

                d_scr0 = XT_LSX2I(pscratch_src, 0);
                d_scr1 = XT_LSX2I(pscratch_src, 8);
                d_scr2 = XT_LSX2I(pscratch_src, 16);
                d_scr3 = XT_LSX2I(pscratch_src, 24);

                filt_align = AE_LA128_PP(pfilt);
                AE_LASX2X2_IP(d_fil0, d_fil10, filt_align, pfilt);
                pfilt = (xtfloatx4 *)((FLOAT32*)pfilt +((stride1 >> 2) -4));

                filt_align = AE_LA128_PP(pfilt);
                AE_LASX2X2_IP(d_fil1, d_fil11, filt_align, pfilt);
                pfilt = (xtfloatx4 *)((FLOAT32*)pfilt +((stride1 >> 2) -4));
                
                filt_align = AE_LA128_PP(pfilt);
                AE_LASX2X2_IP(d_fil2, d_fil12, filt_align, pfilt);
                pfilt = (xtfloatx4 *)((FLOAT32*)pfilt + ((stride1 >> 2) -4));
                
                filt_align = AE_LA128_PP(pfilt);
                AE_LASX2X2_IP(d_fil3, d_fil13, filt_align, pfilt);
                pfilt = (xtfloatx4 *)((FLOAT32*)pfilt + ((stride1 >> 2) -4));

                MADDQ_S(d_scr0, d_scr1, d_fil0, d_fil1, d_inp);
                MADDQ_S(d_scr2, d_scr3, d_fil2, d_fil3, d_inp);
                MADDQ_S(d_scr0, d_scr1, d_fil10, d_fil11, d_inp1);
                MADDQ_S(d_scr2, d_scr3, d_fil12, d_fil13, d_inp1);

                XT_SSX2I(d_scr0, pscratch_src, 0);
                XT_SSX2I(d_scr1, pscratch_src, 8);
                XT_SSX2I(d_scr2, pscratch_src, 16);
                XT_SSX2I(d_scr3, pscratch_src, 24);
                pscratch_src = (xtfloatx2*)((FLOAT32*)pscratch_src + 8);
              }
              
              for (out_channel = 0; out_channel < (output_depth&0x3); ++out_channel)
              {
                xtfloatx2 d_fil0, d_fil10;
                filt_align = AE_LA128_PP((xtfloatx4 *)pfilt);
                AE_LASX2X2_IP(d_fil0, d_fil10, filt_align, pfilt);
				pfilt = (xtfloatx4 *)((FLOAT32*)pfilt + ((stride1 >> 2) -4));
                xtfloatx2 d_scr = XT_LSX2I(pscratch_src, 0);
                d_scr = ADD_SX2(d_scr, MUL_SX2(d_inp, d_fil0));
                d_scr = ADD_SX2(d_scr, MUL_SX2(d_inp1, d_fil10));
                XT_SSX2IP(d_scr, pscratch_src, 2*sizeof(FLOAT32));
              }
            }
          }
        }
        xtfloat* px_inp_align = (xtfloat*)p_inp_align;
        for (in_channel=0 ; in_channel < (input_depth&0x3); in_channel++)
        {
          xtfloat d_inp;
          xtfloatx2 d_inpx2;
          xtfloatx2 zero = ZERO_SX2();
          XT_LSIP(d_inp, px_inp_align, 4);
          for (int filter_y = filt_y_min; filter_y < filt_y_max; ++filter_y)
          {
            for (int filter_x = filt_x_min; filter_x < filt_x_max; ++filter_x)
            {
              // Compute output element location.
              int out_x = out_x_orig + filter_x;
              int out_y = out_y_orig + filter_y;
              xtfloatx2* __restrict__ pscratch_src = (xtfloatx2 *)((FLOAT32*)&pscratch64[out_y*output_width*output_depth+out_x*output_depth]);
              FLOAT32* __restrict__ pfilt = (FLOAT32*)&filter_data[filter_y*filter_width*input_depth + filter_x*input_depth + (input_depth&~0x3) + in_channel];

              for (int out_channel = 0; out_channel < output_depth; out_channel++)
              {
                xtfloat   d_fil;
                xtfloatx2 d_filx2;
                xtfloatx2 d_scr0;

                d_scr0 = XT_LSX2I(pscratch_src, 0);
                XT_LSXP(d_fil, pfilt, stride1);
                d_inpx2 = XT_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_inp), zero);
                d_filx2 = XT_SEL32_LL_SX2(AE_MOVXTFLOATX2_FROMXTFLOAT(d_fil), zero);
                d_scr0 = ADD_SX2(d_scr0, MUL_SX2(d_inpx2, d_filx2));
                XT_SSX2IP(d_scr0, pscratch_src, 8);
              }
            }
          }
        }
      }
    } 
  }
  if(bias_data)
  {
    FLOAT32 *pbias = (FLOAT32*)bias_data;

    for (int out_channel = 0; out_channel < output_depth; ++out_channel)
    {
      xtfloatx2 acc;
      xtfloat dbias;
      xtfloatx2 *pscratch = (xtfloatx2 *)((FLOAT32*)&pscratch64[out_channel]);
      xtfloat *pout = (xtfloat *)((FLOAT32*)&output_data[out_channel]);
      XT_LSIP(dbias, pbias, sizeof(FLOAT32));

      for (int i = 0; i < (output_height*output_width); i++)
      {
        XT_LSX2XP(acc, pscratch, 2*output_depth*sizeof(FLOAT32));
        XT_SSXP(ADD_S(XT_RADD_SX2(acc), dbias), pout, output_depth*sizeof(FLOAT32));
      }
    }
  }
  else
  {
    xtfloatx2 *pscratch = (xtfloatx2 *)scratch_buffer;
    FLOAT32 *pout = (FLOAT32*)output_data;
    for (int i = 0; i < output_height*output_width; i++)
    {
      for (int out_channel = 0; out_channel < output_depth; ++out_channel)
      {
        xtfloatx2 acc;
        XT_LSX2IP(acc, pscratch, 2*sizeof(FLOAT32));
        XT_SSIP(XT_RADD_SX2(acc), pout, sizeof(FLOAT32));
      }
    }
  }    
}
#endif

/* Handle sub-kernel formation and transpose */
static inline void tconv2d_std_reorder_kernel_f32
    (pVOID p_scratch
     ,const FLOAT32* p_kernel
     ,WORD32 kernel_height
     ,WORD32 kernel_width
     ,WORD32 input_channels
     ,WORD32 output_channels
     ,WORD32 x_stride
     ,WORD32 y_stride
     ,WORD32 subker_size
     ,WORD32 n_subker
    )
{
  (VOID) n_subker;
  WORD32 kIdx, kIdy;
  WORD32 kernelIdx;

  WORD32 kx, ky, outCh, inIdx;
  WORD32 kxStart, kyStart;

  WORD32 pitch_d = input_channels;
  WORD32 pitch_w = kernel_width * input_channels;
  WORD32 pitch_h = kernel_height * kernel_width * input_channels;

  WORD32 subkermax_w = (kernel_width + x_stride - 1) / x_stride;
  WORD32 subkermax_h = (kernel_height + y_stride - 1) / y_stride;
  
	FLOAT32 *p_ker;

  /* Conversion from NDWH -> DNWH,                       */
  /* transposing of kernels and formation of sub-kernels */
  for (kIdy = 0; kIdy < y_stride; kIdy++)
  {
    for (kIdx = 0; kIdx < x_stride; kIdx++)
    {
      kernelIdx = kIdy * x_stride + kIdx;
      FLOAT32 *p_dst = ((FLOAT32 *)p_scratch + kernelIdx * subker_size);

      kyStart = kernel_height - 1 - ((kernel_height + y_stride - kIdy - 1) % y_stride);
      kxStart = kernel_width - 1 - ((kernel_width + x_stride - kIdx - 1) % x_stride);
      WORD32 subker_w = (kernel_width + x_stride - kIdx - 1) / x_stride;
      WORD32 subker_h = (kernel_height + y_stride - kIdy - 1) / y_stride;

      for (outCh = 0; outCh < output_channels; outCh++)      /* N */
      {
        p_dst += (subkermax_h - subker_h) * subkermax_w * input_channels; /* Add top padding to the subkernel */
        for (ky = kyStart; ky >= 0; ky -= y_stride)          /* H */
        {
          p_dst += (subkermax_w - subker_w) * input_channels; /* Add left padding to the subkernel */
          for (kx = kxStart; kx >= 0; kx -= x_stride)        /* W */
          {
            p_ker = (FLOAT32*)&p_kernel[inIdx = outCh * pitch_h + ky * pitch_w + kx * pitch_d];
            xa_nn_memcpy(p_dst, p_ker, input_channels*sizeof(FLOAT32));
            p_dst+=input_channels;
          }
        }
      }
    }
  }
}

static inline void tconv_pad_f32(
    WORD32 out_width,
    WORD32 out_height,
    WORD32 out_channels,
    WORD32 out_channels_offset,
    WORD32 out_width_offset,
    WORD32 out_height_offset,
    const FLOAT32* __restrict__ p_bias,
    FLOAT32 *p_out,
    WORD32 idx_width,
    WORD32 idx_height)
{
  WORD32 i, j, k;

  /* When kernel has no valid input for convolution, output is just bias */
  for(i = idx_height; i < out_height; i++)
  {
    for(j = idx_width; j < out_width; j++)
    {
      xtfloat *ptrout = (xtfloat*)&p_out[i * out_height_offset + j * out_width_offset];
      xtfloat *pbias = (xtfloat*)p_bias;
      xtfloat q1;
      for(k = 0; k < out_channels; k++)
      {
        q1 = ZERO_S();
        if(p_bias!= NULL){
          AE_LSIP(q1, pbias, 4);
        }
        AE_SSXP(q1, ptrout, out_channels_offset*sizeof(FLOAT32));
      }
    }
  }
}

static inline void transpose_conv2d_std_f32(FLOAT32* output_data,
		const FLOAT32* input_data,
		const FLOAT32* filter_data,
		const FLOAT32* bias_data,
		int stride_width, int stride_height,
		int pad_width, int pad_height,
		int input_depth, int output_depth,
		int input_height, int input_width,
		int filter_height, int filter_width,
		int output_height, int output_width,
		int num_elements,
		pVOID scratch_buffer)
{
  (VOID) num_elements;
  /* Transpose and Reorder the kernel into sub-kernels */
  WORD32 subkerX_max = (filter_width + stride_width - 1) / stride_width;
  WORD32 subkerY_max = (filter_height + stride_height - 1) / stride_height;
  WORD32 n_subker = stride_width * stride_height;
  WORD32 subker_size = subkerX_max * subkerY_max * input_depth * output_depth;
  /* memset the kernel reordering memory on scratch */
  memset(scratch_buffer, (WORD8)0, subker_size * n_subker * sizeof(FLOAT32));

  tconv2d_std_reorder_kernel_f32(scratch_buffer, filter_data, filter_height, filter_width, input_depth, output_depth, stride_width, stride_height, subker_size, n_subker);

  /* Calculate padding values */
  WORD32 x_pad = subkerX_max - 1;
  WORD32 y_pad = subkerY_max - 1;
  WORD32 y_b_pad = subkerY_max - 1;

  /* Calculate valid output dims */
  WORD32 orig_valid_out_h = XT_MIN(output_height, filter_height + stride_height * (input_height -1) - pad_height);
  WORD32 orig_valid_out_w = XT_MIN(output_width, filter_width + stride_width * (input_width -1) - pad_width);
  WORD32 valid_out_h = orig_valid_out_h + pad_height;
  WORD32 valid_out_w = orig_valid_out_w + pad_width;
  WORD32 out_h_per_subker = orig_valid_out_h / stride_height;
  WORD32 pad_h_per_subker = pad_height / stride_height;

  /* Calculate valid and actual output offsets */
  WORD32 out_data_format = 0; // NHWC
  WORD32 out_channels_offset = out_data_format ? valid_out_h * valid_out_w : 1;
  WORD32 final_out_channels_offset = out_data_format ? output_height * output_width : 1;
  WORD32 final_out_height_offset = out_data_format ? output_width : output_width * output_depth;
  WORD32 final_out_width_offset = out_data_format ? 1 : output_depth;

  /* Calculate pointers for different sections on scratch buffer */
  WORD32 kernel_size = PADDED_SIZE(subker_size * n_subker, ALIGNMENT_16 >> 2);
  FLOAT32 *p_trp_ker = (FLOAT32 *)scratch_buffer; 
  FLOAT32 *p_scr_cnv = (FLOAT32 *)((FLOAT32 *)scratch_buffer + kernel_size);

  /* Handle cases that have less valid output dimension than the output dimension given by the user */
  if((orig_valid_out_h) < output_height)
  {
    tconv_pad_f32(output_width, output_height, output_depth, final_out_channels_offset, final_out_width_offset, final_out_height_offset, bias_data, output_data, 0, XT_MAX(0,orig_valid_out_h));
  }

  if((orig_valid_out_w) < output_width)
  {
    tconv_pad_f32(output_width, output_height, output_depth, final_out_channels_offset, final_out_width_offset, final_out_height_offset, bias_data, output_data, XT_MAX(0,orig_valid_out_w), 0);
  }
  
  if((out_h_per_subker < 0))
  {
    tconv_pad_f32(output_width, output_height, output_depth, final_out_channels_offset, final_out_width_offset, final_out_height_offset, bias_data, output_data, 0, 0);
  return;
  }

  WORD32 j;
  WORD32 input_bytewidth = 4;
  VOID *pp_inp = (VOID *)(input_data);

  /* Conv 2D Standard code init */
  /* Here the x-pad and y-pad values are controlled by the filter dimensions
   * x-r-pad = filter_width - 1 and y-b-pad = filter_height - 1
   * x_pad and y_pad depend on kernel dimension and the padding.
  */
  xa_nn_conv_state_t *p_state = (xa_nn_conv_state_t *)p_scr_cnv;
  xa_nn_transpose_conv_init_state((void*)p_state
      ,(void*)p_trp_ker
      ,input_height
      ,input_depth
      ,subkerY_max
      ,subkerX_max
      ,-1);

  /* When kernel convolves over input region */
  // Initialize circular buffer
  conv2d_std_init_cir_buf(input_depth, input_depth, input_bytewidth, input_width, input_height, y_pad, y_b_pad, x_pad, subkerX_max, 1, (VOID**)&pp_inp, p_state);

  // Index to padded input width
  WORD32 idx_beg_inp_width_pad = subkerX_max - 1;
  idx_beg_inp_width_pad = idx_beg_inp_width_pad < 0 ? 0 : idx_beg_inp_width_pad;

  FLOAT32 *po_tmp;
  WORD32 rem_val_out_w = valid_out_w % stride_width;
  WORD32 pad_w = pad_width;
  
  // Process Loop to compute one output plane [out_height x out_channels] per iteration
  WORD32 out_w_looopcnt = valid_out_w / stride_width;
  for(j = 0; j < out_w_looopcnt; j++)
  {
    // Add x_stride x (input_height x input_channels) new planes to circular buffer
    conv2d_std_update_cir_buf(input_depth, input_depth, input_bytewidth, input_width, input_height, y_pad, y_b_pad, x_pad, subkerX_max, 1, (VOID**)&pp_inp, idx_beg_inp_width_pad, p_state);

    // Update index to input width padded
    idx_beg_inp_width_pad += 1;

    int kernelIdx;
    for (int kIdx = 0; kIdx < stride_width; kIdx++, pad_w--)
    {
      WORD32 rem_val_out_h = (valid_out_h - pad_height) % stride_height;
      WORD32 is_pad_w = (pad_w > 0);

      if(!is_pad_w)
      {
        WORD32 pad_h_ky = stride_height - (pad_height % stride_height); // Required to handle valid inp_h for subkernel
        po_tmp = output_data;
        for (int kIdy = 0; kIdy < stride_height; kIdy++, rem_val_out_h--, pad_h_ky--)
        {
          kernelIdx = ((kIdy + pad_height) % stride_height) * stride_width + kIdx;
          FLOAT32 *p_subkernel = ((FLOAT32 *)p_trp_ker + kernelIdx * subker_size);
          WORD32 rem_out_h_per_subker = (rem_val_out_h > 0) ? 1 : 0; 

          // Adjust the circ_buf pointer as per pad_height
          WORD32 cir_buf_inp_offset = pad_h_per_subker * input_depth * subkerX_max;
          cir_buf_inp_offset = (pad_h_ky > 0) ? cir_buf_inp_offset : cir_buf_inp_offset + input_depth * subkerX_max;
          ae_int16x4 *p16x4_inp_cir_buf = (ae_int16x4 *)(p_state->cir_buf.p_curr);
          AE_ADDCIRC16X4_XC(p16x4_inp_cir_buf, cir_buf_inp_offset * input_bytewidth);
          FLOAT32 *p_inp_cir_buf = (FLOAT32 *)p16x4_inp_cir_buf;
          
          // Convolution using matXvec with matrix as circular buffer
          xa_nn_matXvec_f32_circ
          (po_tmp /* output */
           ,p_inp_cir_buf/* matrix: rows x cols */
           ,p_subkernel /* vec: cols */
           ,(FLOAT32 *)bias_data /* bias */
           ,out_h_per_subker + rem_out_h_per_subker /* rows */
           ,input_depth * subkerX_max * subkerY_max /* cols */
           ,input_depth * subkerX_max /* row_offset */
           ,output_depth /* vec_count */
           ,input_depth * subkerX_max * subkerY_max /* vec_stride */
           ,out_channels_offset /* out_col_offset */
           ,final_out_height_offset * stride_height /* out_row_offset */
          );
          po_tmp += final_out_height_offset;
        }
      }
      output_data = is_pad_w ? output_data : output_data + output_depth;
    }
  }

  /* Tail loop depending on remaining valid_out_width */
  if(rem_val_out_w)
  {
    // Add x_stride x (input_height x input_channels) new planes to circular buffer
    conv2d_std_update_cir_buf(input_depth, input_depth, input_bytewidth, input_width, input_height, y_pad, y_b_pad, x_pad, subkerX_max, 1, (VOID**)&pp_inp, idx_beg_inp_width_pad, p_state);

    // Update index to input width padded
    idx_beg_inp_width_pad += 1;

    int kernelIdx;
    for (int kIdx = 0; kIdx < rem_val_out_w; kIdx++, pad_w--)
    {
      WORD32 rem_val_out_h = (valid_out_h - pad_height) % stride_height;
      WORD32 is_pad_w = (pad_w > 0);

      if(!is_pad_w)
      {
        WORD32 pad_h_ky = stride_height - (pad_height % stride_height); // Required to handle valid inp_h for subkernel
        po_tmp = output_data;
        for (int kIdy = 0; kIdy < stride_height; kIdy++, rem_val_out_h--, pad_h_ky--)
        {
          kernelIdx = ((kIdy + pad_height) % stride_height) * stride_width + kIdx;
          FLOAT32 *p_subkernel = ((FLOAT32 *)p_trp_ker + kernelIdx * subker_size);
          WORD32 rem_out_h_per_subker = (rem_val_out_h > 0) ? 1 : 0; 
          // Adjust the circ_buf pointer as per pad_height
          WORD32 cir_buf_inp_offset = pad_h_per_subker * input_depth * subkerX_max;
          cir_buf_inp_offset = (pad_h_ky > 0) ? cir_buf_inp_offset : cir_buf_inp_offset + input_depth * subkerX_max;
          ae_int16x4 *p16x4_inp_cir_buf = (ae_int16x4 *)(p_state->cir_buf.p_curr);
          AE_ADDCIRC16X4_XC(p16x4_inp_cir_buf, cir_buf_inp_offset * input_bytewidth);
          FLOAT32 *p_inp_cir_buf = (FLOAT32 *)p16x4_inp_cir_buf;
          
          // Convolution using matXvec with matrix as circular buffer
          xa_nn_matXvec_f32_circ
          (po_tmp /* output */
           ,p_inp_cir_buf/* matrix: rows x cols */
           ,p_subkernel /* vec: cols */
           ,(FLOAT32 *)bias_data /* bias */
           ,out_h_per_subker + rem_out_h_per_subker /* rows */
           ,input_depth * subkerX_max * subkerY_max /* cols */
           ,input_depth * subkerX_max /* row_offset */
           ,output_depth /* vec_count */
           ,input_depth * subkerX_max * subkerY_max /* vec_stride */
           ,out_channels_offset /* out_col_offset */
           ,final_out_height_offset * stride_height /* out_row_offset */
          );
          po_tmp += final_out_height_offset;
        }
      }
      output_data = is_pad_w ? output_data : output_data + output_depth;
    }
  }
}

int xa_nn_transpose_conv_f32(FLOAT32* output_data,
    const FLOAT32* input_data,
    const FLOAT32* filter_data,
    const FLOAT32* bias_data,
    int stride_width, int stride_height,
    int pad_width, int pad_height,
    int input_depth, int output_depth,
    int input_height, int input_width,
    int filter_height, int filter_width,
    int output_height, int output_width,
    int num_elements, int num_groups,
    void* scratch_buffer)
{
  /* NULL pointer checks */
  XA_NNLIB_ARG_CHK_PTR(output_data, -1);
  XA_NNLIB_ARG_CHK_PTR(filter_data, -1);
  XA_NNLIB_ARG_CHK_PTR(input_data, -1);
  XA_NNLIB_ARG_CHK_PTR(scratch_buffer, -1);
  /* Pointer alignment checks */
  XA_NNLIB_ARG_CHK_ALIGN(output_data, sizeof(FLOAT32), -1);
  XA_NNLIB_ARG_CHK_ALIGN(filter_data, sizeof(FLOAT32), -1);
  XA_NNLIB_ARG_CHK_ALIGN(input_data, sizeof(FLOAT32), -1);
  XA_NNLIB_ARG_CHK_ALIGN(bias_data, sizeof(FLOAT32), -1);
  XA_NNLIB_ARG_CHK_ALIGN(scratch_buffer, sizeof(FLOAT32), -1);
  /* Basic Parameter checks */
  XA_NNLIB_ARG_CHK_COND((input_height <= 0 || input_width <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((input_depth <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((filter_height <= 0 || filter_width <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((output_depth <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((stride_height <= 0 || stride_width <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((pad_height < 0 || pad_width < 0), -1);
  XA_NNLIB_ARG_CHK_COND((output_height <= 0 || output_width <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((num_elements <= 0), -1);

  /* Temporary change till we add suppport for group > 1 */
  (void)num_groups;
  
  int ker_grt_inp = (filter_width > input_width || filter_height > input_height);
  int str_leq_ker = (stride_width <= filter_width && stride_height <= filter_height);

  if(!ker_grt_inp && str_leq_ker)
  {
    transpose_conv2d_std_f32(output_data, input_data, filter_data, bias_data,
    stride_width, stride_height, pad_width, pad_height, input_depth, output_depth,
		input_height, input_width, filter_height, filter_width,	output_height, output_width,
		num_elements, scratch_buffer);
  }
  else
  {
    tconv2d_f32(output_data, input_data, filter_data, bias_data,
    stride_width, stride_height, pad_width, pad_height, input_depth, output_depth,
		input_height, input_width, filter_height, filter_width,	output_height, output_width,
		num_elements, scratch_buffer);
  }

	return 0;
}
#endif
