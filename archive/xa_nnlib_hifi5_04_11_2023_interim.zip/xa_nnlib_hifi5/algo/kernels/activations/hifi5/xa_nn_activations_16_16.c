/*******************************************************************************
* Copyright (c) 2018-2023 Cadence Design Systems, Inc.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to use this Software with Cadence processor cores only and
* not with any other processors and platforms, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

******************************************************************************/
#include "xa_type_def.h"
#include "common.h"
#include "xa_nnlib_err_chk.h"

#define MAX_WORD16 (int)0x00007fff
#define MIN_WORD16 (int)0xffff8000

/*
 * inp: p_vec: 2 byte aligned input pointer
 * out: p_out: 2 byte aligned output pointer */
WORD32 xa_nn_vec_activation_min_max_16_16(WORD16 * __restrict__ p_out,
                                      const  WORD16 * __restrict__ p_vec,
                                      int    activation_min,
                                      int    activation_max,
                                      WORD32 vec_length)
{
    int i;
    ae_int16x4 x, y, min, max;
    ae_valignx2 align_src, align_dst;

    /* NULL pointer checks */
    XA_NNLIB_ARG_CHK_PTR(p_out, -1);
    XA_NNLIB_ARG_CHK_PTR(p_vec, -1);

    /* Basic Parameter checks */
    XA_NNLIB_ARG_CHK_COND((vec_length <= 0), -1);
    XA_NNLIB_ARG_CHK_COND((activation_max < activation_min), -1);

    WORD16 *p_o = p_out;
    WORD16 *p_v = (WORD16 *)p_vec;

    min  = AE_MOVDA16(activation_min);
    max  = AE_MOVDA16(activation_max);

    align_src = AE_LA128_PP((ae_int16x8 *)p_v);
    align_dst = AE_ZALIGN128(); // zero alignment reg

    if((activation_max >= MAX_WORD16) && (activation_min <= MIN_WORD16))
    {
        for(i=0; i<(vec_length >> 3); i++)
        {
            AE_LA16X4X2_IP(x, y, align_src, (ae_int16x8 *)p_v);
            AE_SA16X4X2_IP(x, y, align_dst, (ae_int16x8 *)p_o);
        }
        int rem_itr = (vec_length & 7);
        {
            AE_LAV16X4X2_XP(x, y, align_src, (ae_int16x8 *)p_v, (rem_itr << 1));
            AE_SAV16X4X2_XP(x, y, align_dst, (ae_int16x8 *)p_o, (rem_itr << 1));
        }
        AE_SA128POS_FP(align_dst, p_o); // finalize the stream
    }
    else if((activation_max < MAX_WORD16) && (activation_min <= MIN_WORD16))
    {
        for(i=0; i<(vec_length >> 3); i++)
        {
            AE_LA16X4X2_IP(x, y, align_src, (ae_int16x8 *)p_v);

            x = AE_MIN16(x, max);
            y = AE_MIN16(y, max);

            AE_SA16X4X2_IP(x, y, align_dst, (ae_int16x8 *)p_o);
        }
        int rem_itr = vec_length & 7;
        {
            AE_LAV16X4X2_XP(x, y, align_src, (ae_int16x8 *)p_v, (rem_itr << 1));

            x = AE_MIN16(x, max);
            y = AE_MIN16(y, max);

            AE_SAV16X4X2_XP(x, y, align_dst, (ae_int16x8 *)p_o, (rem_itr << 1));
        }

        AE_SA128POS_FP(align_dst, p_o); // finalize the stream
    }
    else if((activation_max >= MAX_WORD16) && (activation_min > MIN_WORD16))
    {
        for(i=0; i<(vec_length >> 3); i++)
        {
            AE_LA16X4X2_IP(x, y, align_src, (ae_int16x8 *)p_v);

            x = AE_MAX16(x, min);
            y = AE_MAX16(y, min);

            AE_SA16X4X2_IP(x, y, align_dst, (ae_int16x8 *)p_o);
        }
        int rem_itr = (vec_length & 7);
        {
            AE_LAV16X4X2_XP(x, y, align_src, (ae_int16x8 *)p_v, rem_itr << 1);

            x = AE_MAX16(x, min);
            y = AE_MAX16(y, min);

            AE_SAV16X4X2_XP(x, y, align_dst, (ae_int16x8 *)p_o, rem_itr << 1);
        }
        AE_SA128POS_FP(align_dst, p_o); // finalize the stream
    }
    else
    {
        for(i=0; i<(vec_length >> 3); i++)
        {
            AE_LA16X4X2_IP(x, y, align_src, (ae_int16x8 *)p_v);

            AE_MINMAX16(x, min, max);
            AE_MINMAX16(y, min, max);

            AE_SA16X4X2_IP(x, y, align_dst, (ae_int16x8 *)p_o);
        }
        int rem_itr = (vec_length & 7);
        {
            AE_LAV16X4X2_XP(x, y, align_src, (ae_int16x8 *)p_v, (rem_itr << 1));

            AE_MINMAX16(x, min, max);
            AE_MINMAX16(y, min, max);

            AE_SAV16X4X2_XP(x, y, align_dst, (ae_int16x8 *)p_o, (rem_itr << 1));
        }
        AE_SA128POS_FP(align_dst, p_o); // finalize the stream
    }

    return 0;
}

/*
 * ReLU 16-bit:
 */
WORD32 xa_nn_vec_relu_16_16(
    WORD16       * __restrict__ p_out,
    const WORD16 * __restrict__ p_vec,
    WORD16       threshold,
    WORD32       vec_length)
{
    xa_nn_vec_activation_min_max_16_16(p_out,
                                      p_vec,
                                      0,
                                      threshold,
                                      vec_length);

    return 0;
}
/*
 * ReLU Standard 16-bit:
 */
WORD32 xa_nn_vec_relu_std_16_16(
    WORD16       * __restrict__ p_out,
    const WORD16 * __restrict__ p_vec,
    WORD32       vec_length)
{

    xa_nn_vec_activation_min_max_16_16(p_out,
                                      p_vec,
                                      0,
                                      MAX_WORD16,
                                      vec_length);
  return 0;
}



WORD32 xa_nn_vec_sigmoid_16_16(WORD16 *p_out,         /* result, Q0.15     */
                               const WORD16 *p_vec,   /* input data, Q3.12 */
                               WORD32 vec_length)     /* length of vectors */
{
  /* NULL pointer checks */
  XA_NNLIB_ARG_CHK_PTR(p_out, -1);
  XA_NNLIB_ARG_CHK_PTR(p_vec, -1);
  /* Pointer alignment checks */
  XA_NNLIB_ARG_CHK_ALIGN(p_out, sizeof(WORD16), -1);
  XA_NNLIB_ARG_CHK_ALIGN(p_vec, sizeof(WORD16), -1);
  /* Basic Parameter checks */
  XA_NNLIB_ARG_CHK_COND((vec_length <= 0), -1);

#if defined(AE_SIGMOID16X4X2) && defined(USE_HIFI_ACT_TIE)
  int i;
  ae_int16x4 z32_op, z10_op, z32, z10;
  ae_valignx2 align_src_hf5_0, align_dst_hf5_0;
  ae_int16x4 r_mult = AE_MOVDA16((0x4000)); /* Multiplier value emulating arithmetic right_shift = 1 */
  ae_int16x4 mask = AE_MOVDA16(0x7fff); /* Mask value to make the sign bit 0 */

  const ae_int16x8 *p_in_0  = (const ae_int16x8 *)p_vec;
  ae_int16x8 *__restrict p_o_0 = (ae_int16x8 *)p_out;

  align_src_hf5_0 = AE_LA128_PP(p_in_0);
  align_dst_hf5_0 = AE_ZALIGN128();

  WUR_AE_SAR(4);

  for(i=0; i<(vec_length >> 3); i++)
  {
    AE_LA16X4X2_IP(z32, z10, align_src_hf5_0, p_in_0);

    AE_SIGMOID16X4X2(z32_op, z10_op, z32, z10);
    z32_op = AE_SRLI16(z32_op, 1);
    z10_op = AE_MULFP16X4S(z10_op, r_mult);
    z10_op = AE_AND16(z10_op, mask);

    AE_SA16X4X2_IP(z32_op, z10_op, align_dst_hf5_0, p_o_0);
  }

  int rem_itr = vec_length & 7;
  // remainder loop
  if(rem_itr > 0)
  {
    AE_LAV16X4X2_XP(z32, z10, align_src_hf5_0, p_in_0, (rem_itr << 1));

    AE_SIGMOID16X4X2(z32_op, z10_op, z32, z10);
    z32_op = AE_SRLI16(z32_op, 1);
    z10_op = AE_MULFP16X4S(z10_op, r_mult);
    z10_op = AE_AND16(z10_op, mask);

    AE_SAV16X4X2_XP(z32_op, z10_op, align_dst_hf5_0, p_o_0, (rem_itr << 1));
  }
  AE_SA128POS_FP(align_dst_hf5_0, p_o_0);

#else
  int i;
  ae_int16x4 x3210, y3210;
  ae_int16x4 out0;
  ae_int16x4 zero16;
  ae_int16x4 CT_1_BY_8 = AE_MOVDA16(CONSTANT_1_OVER_8);
  ae_int16x4 CT_1_BY_3 = AE_MOVDA16(CONSTANT_1_OVER_3);
  ae_int16x4 CT = AE_MOVDA16(CONSTANT_TERM);
  ae_int16x4 ONE = AE_MOVDA16(1);
  xtbool4 is_neg0, is_zero0;
  ae_int16x4 exp_y3210, one_half;
  ae_int16x4 z3210;
  ae_valign align_src_hf5, align_dst_hf5;
  ae_valign align_src_hf5_1;

  const ae_int16x4 *p_in  = (const ae_int16x4 *)p_vec;
  const ae_int16x4 *p_in1  = (const ae_int16x4 *)p_vec;
  ae_int16x4 *p_o = (ae_int16x4 *)p_out;

  align_src_hf5 = AE_LA64_PP(p_in);
  align_src_hf5_1 = AE_LA64_PP(p_in1);
  align_dst_hf5 = AE_ZALIGN64();

  zero16 = AE_ZERO16();
  one_half = AE_SLAI16(ONE, 14);

#pragma concurrent
  for(i=0; i<(vec_length >> 2); i++)
  {
    AE_LA16X4_IP(x3210, align_src_hf5, p_in);

    // Computing Negative value
    y3210 = AE_NEG16S(x3210);
    y3210 = AE_MIN16(y3210, x3210);

    // Compute sigmoid/logistic i.e. one_over_one_plus_x(exp(x))
    EXP_INP16_Q12_X4(exp_y3210, y3210);

    ONE_OVER_ONE_PLUS_X_FOR_X_IN_0_1_16X4(out0, exp_y3210);

    z3210 =  AE_SUB16(AE_MOVDA16(Q15_ONE), out0);

    /* This extra load gives a lot of improvement in loop cycles
     * by reducing register pressure
     */
    AE_LA16X4_IP(x3210, align_src_hf5_1, p_in1);

    is_neg0 = AE_LT16(x3210, zero16);

    AE_MOVT16X4(out0, z3210, is_neg0);

    is_zero0 = AE_EQ16(x3210, zero16);
    AE_MOVT16X4(out0, one_half, is_zero0);

    AE_SA16X4_IP(out0, align_dst_hf5, p_o);
  }
  AE_SA64POS_FP(align_dst_hf5, p_o);

  int rem_itr = (vec_length & 3);
  if(rem_itr > 0)
  {
    ae_int16 *p16_in, *p16_out;
    p16_in = (ae_int16 *)p_in;
    p16_out = (ae_int16 *)p_o;
    x3210 = p16_in[0];
    if(rem_itr > 1)
      x3210 = AE_SEL16_6543(x3210, p16_in[1]);
    if(rem_itr > 2)
      x3210 = AE_SEL16_6543(x3210, p16_in[2]);

    y3210 = AE_NEG16S(x3210);
    y3210 = AE_MIN16(y3210, x3210);

    // Compute sigmoid/logistic i.e. one_over_one_plus_x(exp(x))
    EXP_INP16_Q12_X4(exp_y3210, y3210);

    ONE_OVER_ONE_PLUS_X_FOR_X_IN_0_1_16X4(y3210, exp_y3210);

    z3210 =  AE_SUB16(AE_MOVDA16(Q15_ONE), y3210);

    one_half = AE_SLAI16(ONE, 14);

    is_neg0 = AE_LT16(x3210, zero16);
    is_zero0 = AE_EQ16(x3210, zero16);

    AE_MOVT16X4(y3210, z3210, is_neg0);
    AE_MOVT16X4(y3210, one_half, is_zero0);

    if(rem_itr > 2)
    {
      p16_out[2] = y3210;
      y3210 = AE_SEL16_4321(y3210, y3210);
    }
    if(rem_itr > 1)
    {
      p16_out[1] = y3210;
      y3210 = AE_SEL16_4321(y3210, y3210);
    }
    p16_out[0] = y3210;
  }
#endif

  return 0;
}


/*For Tanh*/

WORD32 xa_nn_vec_tanh_16_16(WORD16 *p_out,
                            const WORD16 *p_vec,
                            WORD32 integer_bits,  /* Number of integer bits to adjust Q-format */
                            WORD32 vec_length)
{
  /* NULL pointer checks */
  XA_NNLIB_ARG_CHK_PTR(p_out, -1);
  XA_NNLIB_ARG_CHK_PTR(p_vec, -1);
  /* Pointer alignment checks */
  XA_NNLIB_ARG_CHK_ALIGN(p_out, sizeof(WORD16), -1);
  XA_NNLIB_ARG_CHK_ALIGN(p_vec, sizeof(WORD16), -1);
  /* Basic Parameter checks */
  XA_NNLIB_ARG_CHK_COND((vec_length <= 0), -1);
  XA_NNLIB_ARG_CHK_COND((integer_bits > 6), -1);

#if defined(AE_TANH16X4X2) && defined(USE_HIFI_ACT_TIE)
  int i;
  ae_int16x4 z32_op, z10_op, z32, z10;
  ae_valignx2 align_src_hf5_0, align_dst_hf5_0;

  const ae_int16x8 *p_in_0  = (const ae_int16x8 *)p_vec;
  ae_int16x8 *__restrict p_o_0 = (ae_int16x8 *)p_out;

  align_src_hf5_0 = AE_LA128_PP(p_in_0);
  align_dst_hf5_0 = AE_ZALIGN128();

  if(integer_bits < 4)
  {
    WUR_AE_SAR(1+integer_bits);

    for(i=0; i<(vec_length >> 3); i++)
    {
      AE_LA16X4X2_IP(z32, z10, align_src_hf5_0, p_in_0);

      AE_TANH16X4X2(z32_op, z10_op, z32, z10);

      AE_SA16X4X2_IP(z32_op, z10_op, align_dst_hf5_0, p_o_0);
    }

    int rem_itr = vec_length & 7;
    // remainder loop
    if(rem_itr > 0)
    {
      AE_LAV16X4X2_XP(z32, z10, align_src_hf5_0, p_in_0, (rem_itr << 1));

      AE_TANH16X4X2(z32_op, z10_op, z32, z10);

      AE_SAV16X4X2_XP(z32_op, z10_op, align_dst_hf5_0, p_o_0, (rem_itr << 1));
    }
    AE_SA128POS_FP(align_dst_hf5_0, p_o_0);
  }
  else
  {
    WUR_AE_SAR(4); /* Allowed shift value is [0, 4], Thus, max value of integer bits = 3 */
    int lshift = integer_bits - 3; /* Left shift value before calling tanh to make integer_bits = 3 */
    ae_int16x4 l_mult = AE_MOVDA16(1 << lshift); /* Multiplier value emulating arithmetic left_shift */

    for(i=0; i<(vec_length >> 3); i++)
    {
      AE_LA16X4X2_IP(z32, z10, align_src_hf5_0, p_in_0);

      z32 = AE_MULP16X16X4S(z32, l_mult);
      z10 = AE_MULP16X16X4S(z10, l_mult);
      AE_TANH16X4X2(z32_op, z10_op, z32, z10);

      AE_SA16X4X2_IP(z32_op, z10_op, align_dst_hf5_0, p_o_0);
    }

    int rem_itr = vec_length & 7;
    // remainder loop
    if(rem_itr > 0)
    {
      AE_LAV16X4X2_XP(z32, z10, align_src_hf5_0, p_in_0, (rem_itr << 1));

      z32 = AE_MULP16X16X4S(z32, l_mult);
      z10 = AE_MULP16X16X4S(z10, l_mult);
      AE_TANH16X4X2(z32_op, z10_op, z32, z10);

      AE_SAV16X4X2_XP(z32_op, z10_op, align_dst_hf5_0, p_o_0, (rem_itr << 1));
    }
    AE_SA128POS_FP(align_dst_hf5_0, p_o_0);
  }
#else

  int i;
  int fract_bits = 16 - 1 - integer_bits;

  ae_int16x4 x0123, y0123, z0123;
  xtbool4 e0123, f0123;
  ae_int16x4 exp_y0123;
  ae_valign align_src_hf5, align_dst_hf5;
  ae_valign align_src_hf5_1;
  ae_int16x4 out1;

  /*Derived variables from constants*/
  ae_int16x4 ONE = AE_MOVDA16(1);
  ae_int16x4 zero16 = AE_ZERO16();
  ae_int16x4 CT_1_BY_8 = AE_MOVDA16(CONSTANT_1_OVER_8);
  ae_int16x4 CT_1_BY_3 = AE_MOVDA16(CONSTANT_1_OVER_3);
  ae_int16x4 CT = AE_MOVDA16(CONSTANT_TERM);

  const ae_int16x4 *p_in  = (const ae_int16x4 *)p_vec;
  const ae_int16x4 *p_in1  = (const ae_int16x4 *)p_vec;
  ae_int16x4 *p_o = (ae_int16x4 *)p_out;

  align_src_hf5 = AE_LA64_PP(p_in);
  align_src_hf5_1 = AE_LA64_PP(p_in1);
  align_dst_hf5 = AE_ZALIGN64();

#pragma concurrent
  for(i=0; i < (vec_length >> 2); i++)
  {
    AE_LA16X4_IP(x0123, align_src_hf5, p_in);

    y0123 = AE_NEG16S(x0123);
    y0123 = AE_MIN16(y0123, x0123);

    EXP_2X_INP16X4(exp_y0123, fract_bits, y0123);

    ONE_MINUS_X_OVER_ONE_PLUS_X_FOR_X_IN_0_1(z0123, exp_y0123);

    /* This extra load gives a lot of improvement in loop cycles
     * by reducing register pressure
     */
    AE_LA16X4_IP(x0123, align_src_hf5_1, p_in1);
    e0123 = AE_LT16(x0123, zero16);

    out1 = z0123;
    AE_MOVT16X4(out1, AE_NEG16S(z0123), e0123);

    //Check if input = 0
    f0123 = AE_EQ16(x0123, zero16);
    AE_MOVT16X4(out1, AE_ZERO16(), f0123);

    AE_SA16X4_IP(out1, align_dst_hf5, (ae_int16x4 *)p_o);
  }
  AE_SA64POS_FP(align_dst_hf5, p_o);

  int rem_itr = vec_length & 3;
  // remainder loop
  if(rem_itr > 0)
  {
    ae_int16 *p16_in, *p16_out;
    p16_in = (ae_int16 *)p_in;
    p16_out = (ae_int16 *)p_o;
    x0123 = p16_in[0];
    if(rem_itr > 1)
      x0123 = AE_SEL16_6543(x0123, p16_in[1]);
    if(rem_itr > 2)
      x0123 = AE_SEL16_6543(x0123, p16_in[2]);

    y0123 = AE_NEG16S(x0123);
    y0123 = AE_MIN16(y0123, x0123);

    EXP_2X_INP16X4(exp_y0123, fract_bits, y0123);

    ONE_MINUS_X_OVER_ONE_PLUS_X_FOR_X_IN_0_1(z0123, exp_y0123);

    e0123 = AE_LT16(x0123, zero16);

    out1 = z0123;
    AE_MOVT16X4(out1, AE_NEG16S(z0123), e0123);

    //Check if input = 0
    f0123 = AE_EQ16(x0123, zero16);
    AE_MOVT16X4(out1, AE_ZERO16(), f0123);

    if(rem_itr > 2)
    {
      p16_out[2] = out1;
      out1 = AE_SEL16_4321(out1, out1);
    }
    if(rem_itr > 1)
    {
      p16_out[1] = out1;
      out1 = AE_SEL16_4321(out1, out1);
    }
    p16_out[0] = out1;
  }
#endif

  return 0;
}
